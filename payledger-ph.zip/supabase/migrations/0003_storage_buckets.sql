-- 0003_storage_buckets.sql
-- Private & public Supabase Storage buckets with strict RLS access

INSERT INTO storage.buckets (id, name, public)
VALUES
  ('employee-photos', 'employee-photos', false),
  ('company-assets', 'company-assets', true),
  ('leave-attachments', 'leave-attachments', false),
  ('payslips', 'payslips', false)
ON CONFLICT (id) DO NOTHING;

-- Company assets: public read, Super Admin write
CREATE POLICY company_assets_public_read ON storage.objects
  FOR SELECT USING (bucket_id = 'company-assets');

CREATE POLICY company_assets_super_admin_write ON storage.objects
  FOR ALL USING (
    bucket_id = 'company-assets' AND public.current_user_role() = 'SUPER_ADMIN'
  );

-- Employee photos: authenticated HR/Admin/Super Admin or owner read; HR/Admin/Super Admin write
CREATE POLICY employee_photos_read ON storage.objects
  FOR SELECT TO authenticated USING (
    bucket_id = 'employee-photos' AND (
      public.current_user_role() IN ('SUPER_ADMIN', 'ADMIN', 'HR')
      OR (storage.foldername(name))[1] = public.current_employee_id()::text
    )
  );

CREATE POLICY employee_photos_write ON storage.objects
  FOR ALL TO authenticated USING (
    bucket_id = 'employee-photos' AND public.current_user_role() IN ('SUPER_ADMIN', 'ADMIN', 'HR')
  );

-- Leave attachments: owner or HR/Admin/Super Admin
CREATE POLICY leave_attachments_read ON storage.objects
  FOR SELECT TO authenticated USING (
    bucket_id = 'leave-attachments' AND (
      public.current_user_role() IN ('SUPER_ADMIN', 'ADMIN', 'HR')
      OR (storage.foldername(name))[1] = public.current_employee_id()::text
    )
  );

CREATE POLICY leave_attachments_write ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (
    bucket_id = 'leave-attachments' AND (
      public.current_user_role() IN ('SUPER_ADMIN', 'ADMIN', 'HR')
      OR (storage.foldername(name))[1] = public.current_employee_id()::text
    )
  );

-- Payslips: owner or payroll authorized admin
CREATE POLICY payslips_read ON storage.objects
  FOR SELECT TO authenticated USING (
    bucket_id = 'payslips' AND (
      public.current_user_role() = 'SUPER_ADMIN'
      OR public.has_permission('can_manage_payroll')
      OR (storage.foldername(name))[1] = public.current_employee_id()::text
    )
  );
