// supabase/functions/provision-super-admin/index.ts
// Protected Edge Function for provisioning the first Super Admin OR creating Admin/HR/Employee accounts by an authorized Super Admin.
// Never uses Google OAuth; stores all user profile data in public.profiles.

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const adminClient = createClient(supabaseUrl, serviceRoleKey);

    const authHeader = req.headers.get('Authorization');
    const body = await req.json();

    // Mode 1: First Super Admin Provisioning (only when zero active SUPER_ADMIN profiles exist)
    if (body.mode === 'FIRST_SUPER_ADMIN') {
      const { count } = await adminClient
        .from('profiles')
        .select('id', { count: 'exact', head: true })
        .eq('role', 'SUPER_ADMIN')
        .eq('is_active', true);

      if ((count ?? 0) > 0) {
        return new Response(
          JSON.stringify({ error: 'Super Admin already exists.' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const { email, password, full_name, phone } = body;
      if (!email || !password || !full_name) {
        return new Response(
          JSON.stringify({ error: 'Email, password, and full name are required.' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const { data: created, error: createErr } = await adminClient.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
        user_metadata: { full_name },
      });
      if (createErr || !created.user) throw createErr ?? new Error('Failed to create user');

      await adminClient.from('profiles').upsert({
        id: created.user.id,
        email,
        full_name,
        phone: phone ?? null,
        role: 'SUPER_ADMIN',
        permissions: {
          can_edit_salary: true,
          can_manage_payroll: true,
          can_manage_holidays: true,
          can_view_reports: true,
        },
        is_active: true,
      });

      await adminClient.from('audit_logs').insert({
        actor_user_id: created.user.id,
        actor_role: 'SUPER_ADMIN',
        action: 'PROVISION_FIRST_SUPER_ADMIN',
        table_name: 'profiles',
        record_id: created.user.id,
        new_value: { email, role: 'SUPER_ADMIN' },
        reason: 'Initial Super Admin bootstrap',
      });

      return new Response(JSON.stringify({ success: true, user_id: created.user.id }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Mode 2: Existing authorized SUPER_ADMIN creates ADMIN, HR, or EMPLOYEE accounts
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'Missing Authorization header' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const callerToken = authHeader.replace('Bearer ', '');
    const { data: callerAuth, error: callerErr } = await adminClient.auth.getUser(callerToken);
    if (callerErr || !callerAuth.user) {
      return new Response(JSON.stringify({ error: 'Unauthorized caller' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { data: callerProfile } = await adminClient
      .from('profiles')
      .select('role, is_active')
      .eq('id', callerAuth.user.id)
      .single();

    if (!callerProfile?.is_active || callerProfile.role !== 'SUPER_ADMIN') {
      return new Response(JSON.stringify({ error: 'Only an active SUPER_ADMIN can create accounts' }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { email, password, full_name, role, employee_id, employee_number, department, position, phone, permissions } = body;
    const { data: newUser, error: userErr } = await adminClient.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { full_name },
    });
    if (userErr || !newUser.user) throw userErr ?? new Error('Unable to create user');

    await adminClient.from('profiles').upsert({
      id: newUser.user.id,
      email,
      full_name,
      phone: phone ?? null,
      department: department ?? null,
      position: position ?? null,
      role: role ?? 'EMPLOYEE',
      employee_id: employee_id ?? null,
      employee_number: employee_number ?? null,
      permissions: permissions ?? {
        can_edit_salary: false,
        can_manage_payroll: false,
        can_manage_holidays: false,
        can_view_reports: role === 'HR' || role === 'ADMIN',
      },
      is_active: true,
    });

    await adminClient.from('audit_logs').insert({
      actor_user_id: callerAuth.user.id,
      actor_role: 'SUPER_ADMIN',
      action: 'CREATE_USER_ACCOUNT',
      table_name: 'profiles',
      record_id: newUser.user.id,
      new_value: { email, role, employee_number },
      reason: 'Created by Super Admin',
    });

    return new Response(JSON.stringify({ success: true, user_id: newUser.user.id }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: (err as Error).message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
