import React, { useEffect, useRef, useState } from 'react';
import { CheckCircle2, XCircle, Clock, Delete, CornerDownLeft, Search } from 'lucide-react';
import { Avatar, StatusLabel } from '../../components/ui/Common';
import { formatManilaDate, formatManilaTime, toManilaDateString, toManilaTime24 } from '../../lib/date/manila';
import { dataService } from '../../services/dataService';
import type { AttendancePunchResult, CompanySettings, Employee } from '../../types/database';

interface LookupInfo {
  found: boolean;
  employee_number?: string;
  full_name?: string;
  position?: string;
  department?: string;
  photo_url?: string | null;
  is_active?: boolean;
  next_event?: 'TIME_IN' | 'TIME_OUT';
}

export function AttendanceTerminalPage({
  company,
  employees,
  onPunchRecorded,
}: {
  company: CompanySettings;
  employees: Employee[];
  onPunchRecorded: () => void;
}) {
  const [employeeNumber, setEmployeeNumber] = useState('');
  const [pin, setPin] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [lookup, setLookup] = useState<LookupInfo | null>(null);
  const [result, setResult] = useState<AttendancePunchResult | null>(null);
  const [clock, setClock] = useState(() => new Date());
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const timer = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Show employee name & next punch state immediately as Employee Number is entered
  useEffect(() => {
    const trimmed = employeeNumber.trim();
    if (!trimmed) {
      setLookup(null);
      return;
    }
    let cancelled = false;
    dataService.lookupEmployeeByNumber(trimmed).then((res) => {
      if (!cancelled) setLookup(res);
    });
    return () => {
      cancelled = true;
    };
  }, [employeeNumber, result]);

  async function submitPunch(numToSubmit?: string) {
    const target = (numToSubmit ?? employeeNumber).trim();
    if (!target || submitting) return;
    setSubmitting(true);
    try {
      const res = await dataService.punchAttendanceByEmployeeNumber(target, {
        pin: pin.trim() || undefined,
        source: 'TERMINAL',
      });
      setResult(res);
      if (res.success) {
        onPunchRecorded();
        setPin('');
        if (!numToSubmit) {
          // Refresh lookup state immediately if user keeps the same number or clear for next entry
          const refreshed = await dataService.lookupEmployeeByNumber(target);
          setLookup(refreshed);
        }
      }
    } finally {
      setSubmitting(false);
      inputRef.current?.focus();
    }
  }

  const activeEmployees = employees
    .filter((e) => e.is_active)
    .filter((e) => {
      if (!searchTerm.trim()) return true;
      const q = searchTerm.toLowerCase();
      return (
        e.employee_number.toLowerCase().includes(q) ||
        e.full_name.toLowerCase().includes(q) ||
        e.department.toLowerCase().includes(q)
      );
    });

  function appendKey(val: string) {
    setEmployeeNumber((prev) => prev + val);
    inputRef.current?.focus();
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Employee Number Attendance Terminal</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Instant alternating Time In / Time Out with zero cooldown delay (1st = In, 2nd = Out, 3rd = In). Timezone:{' '}
            {company.timezone}.
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-lg px-4 py-2 text-right">
          <div className="text-lg font-mono font-bold tabular-nums text-slate-900">
            {toManilaTime24(clock)}
          </div>
          <div className="text-xs text-slate-500">{formatManilaDate(toManilaDateString(clock))}</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 space-y-5">
          {result && (
            <div
              className={`rounded-lg border p-4 ${
                result.success ? 'bg-emerald-50/70 border-emerald-200' : 'bg-rose-50/70 border-rose-200'
              }`}
            >
              {result.success ? (
                <div className="flex items-center gap-4">
                  <Avatar name={result.full_name ?? 'Employee'} src={result.photo_url} size="lg" />
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span className="text-xs font-bold text-emerald-800">
                        {result.event_type === 'TIME_IN' ? 'TIME IN RECORDED' : 'TIME OUT RECORDED'}
                      </span>
                      {result.status && <StatusLabel label={result.status} />}
                    </div>
                    <p className="text-base font-bold text-slate-900 mt-1">{result.full_name}</p>
                    <p className="text-xs text-slate-600">
                      <span className="font-mono font-semibold text-slate-900">{result.employee_number}</span>
                      {' · '}
                      {formatManilaDate(result.work_date)}
                      {' · '}
                      <span className="font-mono font-semibold tabular-nums">
                        {formatManilaTime(result.recorded_at)}
                      </span>
                      {' · '}
                      {result.late_minutes ?? 0}m late · {result.undertime_minutes ?? 0}m UT
                    </p>
                  </div>
                </div>
              ) : (
                <div className="flex items-start gap-3">
                  <XCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                  <div>
                    <h3 className="text-sm font-bold text-rose-900">Unable to Record Attendance</h3>
                    <p className="text-xs text-rose-800 mt-0.5">{result.message}</p>
                  </div>
                </div>
              )}
            </div>
          )}

          <form
            onSubmit={(e) => {
              e.preventDefault();
              submitPunch();
            }}
            className="space-y-4"
          >
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-2">
                Enter Employee Number
              </label>
              <input
                ref={inputRef}
                type="text"
                autoFocus
                value={employeeNumber}
                onChange={(e) => setEmployeeNumber(e.target.value.toUpperCase())}
                placeholder="Enter Employee Number"
                className="w-full px-4 py-3.5 text-xl font-mono font-semibold tracking-wider border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600"
              />
            </div>

            {/* Live Employee Name Preview */}
            {employeeNumber.trim() && (
              <div className="rounded-lg border border-slate-200 bg-slate-50 px-4 py-3">
                {lookup?.found ? (
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <Avatar name={lookup.full_name ?? 'Employee'} src={lookup.photo_url} size="md" />
                      <div className="min-w-0">
                        <p className="text-sm font-bold text-slate-900 truncate">{lookup.full_name}</p>
                        <p className="text-xs text-slate-500 truncate">
                          <span className="font-mono">{lookup.employee_number}</span> · {lookup.position} ·{' '}
                          {lookup.department}
                        </p>
                      </div>
                    </div>
                    <StatusLabel
                      label={lookup.is_active === false ? 'INACTIVE' : `NEXT: ${lookup.next_event === 'TIME_OUT' ? 'TIME OUT' : 'TIME IN'}`}
                      tone={lookup.is_active === false ? 'red' : lookup.next_event === 'TIME_OUT' ? 'orange' : 'blue'}
                    />
                  </div>
                ) : (
                  <p className="text-xs text-slate-500">
                    No matching employee found for <span className="font-mono font-semibold">{employeeNumber.trim()}</span>
                  </p>
                )}
              </div>
            )}

            {company.require_kiosk_pin && (
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Attendance PIN (if required)
                </label>
                <input
                  type="password"
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  placeholder="4–6 digit PIN"
                  className="w-full px-3.5 py-2.5 text-sm font-mono border border-slate-200 rounded-lg"
                />
              </div>
            )}

            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
              {['1', '2', '3', 'EMP-', '4', '5', '6', '2026-', '7', '8', '9', '0'].map((key) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => appendKey(key)}
                  className="py-3 text-sm font-mono font-semibold bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-slate-800 transition-colors"
                >
                  {key}
                </button>
              ))}
              <button
                type="button"
                onClick={() => setEmployeeNumber((prev) => prev.slice(0, -1))}
                className="py-3 text-sm font-medium bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-slate-700 inline-flex items-center justify-center gap-1.5"
              >
                <Delete className="w-4 h-4" />
                Backspace
              </button>
              <button
                type="button"
                onClick={() => {
                  setEmployeeNumber('');
                  setLookup(null);
                  setResult(null);
                }}
                className="py-3 text-sm font-medium bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-slate-700"
              >
                Clear
              </button>
              <button
                type="submit"
                disabled={submitting || !employeeNumber.trim()}
                className="col-span-1 sm:col-span-2 py-3 px-4 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 rounded-lg inline-flex items-center justify-center gap-2"
              >
                <CornerDownLeft className="w-4 h-4" />
                {submitting
                  ? 'Recording...'
                  : lookup?.found
                  ? `Submit ${lookup.next_event === 'TIME_OUT' ? 'Time Out' : 'Time In'}`
                  : 'Submit Time In / Out'}
              </button>
            </div>
          </form>
        </div>

        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-5">
          <div className="flex items-center justify-between gap-2 mb-3">
            <h3 className="text-sm font-semibold text-slate-900">Active Employee Directory</h3>
            <span className="text-xs text-slate-500 font-mono tabular-nums">{activeEmployees.length} active</span>
          </div>
          <div className="relative mb-3">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search name, number, or department..."
              className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg"
            />
          </div>
          <div className="divide-y divide-slate-100 max-h-96 overflow-y-auto">
            {activeEmployees.map((emp) => (
              <div key={emp.id} className="py-2.5 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5 min-w-0">
                  <Avatar name={emp.full_name} src={emp.photo_url} size="sm" />
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-slate-900 truncate">{emp.full_name}</p>
                    <p className="text-xs text-slate-500 font-mono truncate">
                      {emp.employee_number} · {emp.department}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setEmployeeNumber(emp.employee_number);
                    submitPunch(emp.employee_number);
                  }}
                  className="px-2.5 py-1.5 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-md whitespace-nowrap shrink-0 inline-flex items-center gap-1"
                >
                  <Clock className="w-3 h-3" />
                  Punch
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
