import React, { useEffect, useState } from 'react';
import { Lock, Mail, ShieldCheck, ArrowRight, KeyRound, MonitorPlay } from 'lucide-react';
import { dataService } from '../../services/dataService';
import type { UserProfile } from '../../types/database';

export function LoginPage({
  onSignedIn,
  onOpenKioskDirect,
}: {
  onSignedIn: (profile: UserProfile) => void;
  onOpenKioskDirect: () => void;
}) {
  const isLive = dataService.isLiveSupabase();
  const [mode, setMode] = useState<'LOGIN' | 'FORGOT' | 'FIRST_ADMIN'>('LOGIN');
  const [hasSuperAdmin, setHasSuperAdmin] = useState<boolean>(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  useEffect(() => {
    dataService.hasAnySuperAdmin().then(setHasSuperAdmin).catch(() => setHasSuperAdmin(true));
  }, []);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setInfo(null);
    setLoading(true);
    try {
      const profile = await dataService.signInWithPassword(email, password);
      onSignedIn(profile);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  async function handleForgot(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setInfo(null);
    setLoading(true);
    try {
      await dataService.resetPassword(email);
      setInfo('Password reset instructions have been sent to your email address.');
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  async function handleFirstAdmin(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setInfo(null);
    setLoading(true);
    try {
      const profile = await dataService.provisionFirstSuperAdmin({
        email,
        password,
        full_name: fullName,
        phone: phone || undefined,
      });
      onSignedIn(profile);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  async function handlePreviewRole(previewEmail: string, previewPass: string) {
    setError(null);
    setLoading(true);
    try {
      const profile = await dataService.signInWithPassword(previewEmail, previewPass);
      onSignedIn(profile);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between p-4 sm:p-8">
      <div className="max-w-5xl w-full mx-auto flex items-center justify-between py-2">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-blue-600 text-white font-bold flex items-center justify-center text-sm">
            PL
          </div>
          <span className="text-base font-bold text-slate-900 tracking-tight">PayLedger PH</span>
        </div>
        <button
          type="button"
          onClick={onOpenKioskDirect}
          className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-100 whitespace-nowrap shrink-0"
        >
          <MonitorPlay className="w-3.5 h-3.5 text-blue-600" />
          Open Attendance Kiosk
        </button>
      </div>

      <div className="max-w-5xl w-full mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 my-auto py-8 items-stretch">
        <div className="lg:col-span-6 flex flex-col justify-center pr-0 lg:pr-6">
          <p className="text-xs font-semibold text-blue-600 tracking-wide">
            Supabase Auth · Asia/Manila · Employee Number Attendance
          </p>
          <h1 className="text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight mt-2 [text-wrap:balance]">
            Workforce Attendance, DTR &amp; Payroll Operations
          </h1>
          <p className="text-sm sm:text-base text-slate-600 mt-4 leading-relaxed">
            Centralized employee records, Employee Number entrance kiosk check-ins, Philippine holiday &amp; rest day
            multipliers, overtime approvals, and locked payroll snapshots.
          </p>

          <div className="mt-8 grid grid-cols-2 gap-4 border-t border-slate-200 pt-6">
            <div>
              <p className="text-xs text-slate-500">Authentication</p>
              <p className="text-sm font-semibold text-slate-900 mt-0.5">Email &amp; Password (Supabase)</p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Attendance Verification</p>
              <p className="text-sm font-semibold text-slate-900 mt-0.5">Employee Number Terminal</p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Default Schedule</p>
              <p className="text-sm font-semibold text-slate-900 mt-0.5 font-mono tabular-nums">08:00 AM – 05:00 PM</p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Currency &amp; Timezone</p>
              <p className="text-sm font-semibold text-slate-900 mt-0.5">PHP (₱) · Asia/Manila</p>
            </div>
          </div>
        </div>

        <div className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-6 sm:p-8 shadow-xs flex flex-col justify-between">
          <div>
            {!isLive && (
              <div className="mb-5 p-3 rounded-lg bg-amber-50 border border-amber-200 text-xs text-amber-900">
                <p className="font-semibold">Local Preview Database Active</p>
                <p className="mt-0.5 text-amber-800">
                  Supabase URL is set to{' '}
                  <code className="font-mono">https://mmoebxqfovvwzcvoduyz.supabase.co</code>. Add{' '}
                  <code className="font-mono">SUPABASE_KEY</code> or{' '}
                  <code className="font-mono">VITE_SUPABASE_ANON_KEY</code> (anon/publishable key) in AI Studio Secrets
                  to switch to live Supabase.
                </p>
              </div>
            )}

            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-xl font-bold text-slate-900">
                  {mode === 'LOGIN'
                    ? 'Sign in to workspace'
                    : mode === 'FORGOT'
                    ? 'Reset your password'
                    : 'First Super Admin Setup'}
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  {mode === 'LOGIN'
                    ? 'User profiles and permissions are loaded from the database.'
                    : mode === 'FORGOT'
                    ? 'Enter your registered email to receive a reset link.'
                    : 'No active Super Admin exists yet. Provision the initial administrator.'}
                </p>
              </div>
            </div>

            {error && (
              <div className="mb-4 p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-700 font-medium">
                {error}
              </div>
            )}
            {info && (
              <div className="mb-4 p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-700 font-medium">
                {info}
              </div>
            )}

            {mode === 'LOGIN' && (
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1.5">Email address</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@company.ph"
                      className="w-full pl-9 pr-3 py-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600"
                    />
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="block text-xs font-medium text-slate-700">Password</label>
                    <button
                      type="button"
                      onClick={() => {
                        setError(null);
                        setInfo(null);
                        setMode('FORGOT');
                      }}
                      className="text-xs font-medium text-blue-600 hover:underline"
                    >
                      Forgot password?
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter your password"
                      className="w-full pl-9 pr-3 py-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-60 rounded-lg transition-colors"
                >
                  {loading ? 'Signing in...' : 'Sign in'}
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            )}

            {mode === 'FORGOT' && (
              <form onSubmit={handleForgot} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1.5">Registered Email</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@company.ph"
                    className="w-full px-3 py-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setMode('LOGIN')}
                    className="px-4 py-2.5 text-sm font-medium text-slate-700 border border-slate-200 rounded-lg hover:bg-slate-50"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex-1 py-2.5 px-4 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg"
                  >
                    {loading ? 'Sending...' : 'Send Reset Instructions'}
                  </button>
                </div>
              </form>
            )}

            {mode === 'FIRST_ADMIN' && (
              <form onSubmit={handleFirstAdmin} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Juan Dela Cruz"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Admin Email</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="admin@company.ph"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Password</label>
                  <input
                    type="password"
                    required
                    minLength={8}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Minimum 8 characters"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Contact Number (optional)</label>
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+63 917 000 0000"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setMode('LOGIN')}
                    className="px-4 py-2 text-sm font-medium text-slate-700 border border-slate-200 rounded-lg"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex-1 py-2 px-4 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg"
                  >
                    {loading ? 'Provisioning...' : 'Create First Super Admin'}
                  </button>
                </div>
              </form>
            )}

            {!hasSuperAdmin && mode === 'LOGIN' && (
              <div className="mt-4 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setMode('FIRST_ADMIN')}
                  className="w-full inline-flex items-center justify-center gap-2 py-2 px-3 text-xs font-medium text-blue-700 bg-blue-50 border border-blue-200 rounded-lg hover:bg-blue-100"
                >
                  <ShieldCheck className="w-4 h-4" />
                  Provision Initial Super Admin Account
                </button>
              </div>
            )}
          </div>

          {!isLive && mode === 'LOGIN' && (
            <div className="mt-6 pt-5 border-t border-slate-200">
              <div className="flex items-center gap-1.5 text-xs font-medium text-slate-500 mb-2.5">
                <KeyRound className="w-3.5 h-3.5" />
                <span>Preview Mode Role Switcher (No Supabase .env detected)</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => handlePreviewRole('superadmin@payledger.ph', 'PreviewAdmin123!')}
                  className="text-left px-3 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 text-xs"
                >
                  <span className="font-semibold text-slate-900 block">Super Admin</span>
                  <span className="text-slate-500 truncate block">Full system access</span>
                </button>
                <button
                  type="button"
                  onClick={() => handlePreviewRole('admin@payledger.ph', 'PreviewAdmin123!')}
                  className="text-left px-3 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 text-xs"
                >
                  <span className="font-semibold text-slate-900 block">Admin</span>
                  <span className="text-slate-500 truncate block">Operations &amp; Approvals</span>
                </button>
                <button
                  type="button"
                  onClick={() => handlePreviewRole('hr@payledger.ph', 'PreviewHr123!')}
                  className="text-left px-3 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 text-xs"
                >
                  <span className="font-semibold text-slate-900 block">HR</span>
                  <span className="text-slate-500 truncate block">Employees, Leave &amp; DTR</span>
                </button>
                <button
                  type="button"
                  onClick={() => handlePreviewRole('rafael.santos@payledger.ph', 'PreviewEmp123!')}
                  className="text-left px-3 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 text-xs"
                >
                  <span className="font-semibold text-slate-900 block">Employee</span>
                  <span className="text-slate-500 truncate block">EMP-2026-0003 Self-Service</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="max-w-5xl w-full mx-auto text-xs text-slate-500 flex flex-wrap items-center justify-between gap-2 py-2">
        <span>PayLedger PH · Employee Number Attendance &amp; Payroll</span>
        <span>Supabase PostgreSQL + Auth + Storage</span>
      </div>
    </div>
  );
}
