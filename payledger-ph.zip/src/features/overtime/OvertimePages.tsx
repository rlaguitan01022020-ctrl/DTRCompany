import React, { useMemo, useState } from 'react';
import { Check, X, Clock } from 'lucide-react';
import { EmptyState, StatusLabel } from '../../components/ui/Common';
import { formatManilaDate, formatManilaTime, formatPeso } from '../../lib/date/manila';
import { dataService } from '../../services/dataService';
import type {
  AttendanceRecord,
  Employee,
  OvertimeRequest,
  UserProfile,
} from '../../types/database';

export function OvertimeRequestModal({
  actor,
  employee,
  attendance,
  onClose,
  onSubmitted,
  onNotify,
}: {
  actor: UserProfile;
  employee: Employee;
  attendance: AttendanceRecord;
  onClose: () => void;
  onSubmitted: () => void;
  onNotify: (type: 'success' | 'error', title: string, desc?: string) => void;
}) {
  const verifiedHours = useMemo(() => {
    if (!attendance.actual_time_out || !attendance.scheduled_time_out) return 0;
    const diff = (new Date(attendance.actual_time_out).getTime() - new Date(attendance.scheduled_time_out).getTime()) / 3_600_000;
    return Math.max(0, Number(diff.toFixed(2)));
  }, [attendance]);

  const [decision, setDecision] = useState<'YES' | 'NO'>('YES');
  const [requestedHours, setRequestedHours] = useState(String(verifiedHours > 0 ? verifiedHours : 1));
  const [reason, setReason] = useState('');
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (decision === 'YES' && !reason.trim()) {
      onNotify('error', 'Reason required', 'Please describe the overtime task completed.');
      return;
    }
    setSubmitting(true);
    try {
      await dataService.submitOvertimeRequest(actor, {
        attendance_id: attendance.id,
        employee_id: employee.id,
        work_date: attendance.work_date,
        scheduled_time_in: attendance.scheduled_time_in,
        actual_time_in: attendance.actual_time_in,
        scheduled_time_out: attendance.scheduled_time_out,
        actual_time_out: attendance.actual_time_out,
        decision,
        requested_hours: decision === 'YES' ? Number(requestedHours) || 0 : 0,
        verified_hours: verifiedHours,
        reason: decision === 'YES' ? reason.trim() : 'Employee selected NO overtime',
      });
      onNotify(
        'success',
        decision === 'YES' ? 'Overtime Request Submitted' : 'Overtime Declined',
        decision === 'YES'
          ? 'Sent to Admin Overtime Approval (PENDING).'
          : 'Recorded NO selection; no payable overtime generated.'
      );
      onSubmitted();
      onClose();
    } catch (err) {
      onNotify('error', 'Request failed', (err as Error).message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 flex items-center justify-center p-4">
      <form
        onSubmit={handleSubmit}
        className="bg-white border border-slate-200 rounded-xl max-w-lg w-full p-6 space-y-4 shadow-lg"
      >
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-slate-900">Overtime Request</h3>
          <button type="button" onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 border border-slate-200 rounded-lg p-3.5">
          <div>
            <span className="text-slate-500 block">Employee</span>
            <span className="font-semibold text-slate-900">
              {employee.full_name} ({employee.employee_number})
            </span>
          </div>
          <div>
            <span className="text-slate-500 block">Work Date</span>
            <span className="font-mono font-semibold text-slate-900">{formatManilaDate(attendance.work_date)}</span>
          </div>
          <div>
            <span className="text-slate-500 block">Scheduled In / Out</span>
            <span className="font-mono tabular-nums text-slate-900">
              {formatManilaTime(attendance.scheduled_time_in)} – {formatManilaTime(attendance.scheduled_time_out)}
            </span>
          </div>
          <div>
            <span className="text-slate-500 block">Actual In / Out</span>
            <span className="font-mono tabular-nums text-slate-900">
              {formatManilaTime(attendance.actual_time_in)} – {formatManilaTime(attendance.actual_time_out)}
            </span>
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-2">
            Are you requesting payable overtime for this date?
          </label>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setDecision('YES')}
              className={`py-2.5 text-xs font-semibold rounded-lg border ${
                decision === 'YES'
                  ? 'bg-blue-600 text-white border-blue-600'
                  : 'bg-white text-slate-700 border-slate-200'
              }`}
            >
              YES — Submit Overtime Request
            </button>
            <button
              type="button"
              onClick={() => setDecision('NO')}
              className={`py-2.5 text-xs font-semibold rounded-lg border ${
                decision === 'NO'
                  ? 'bg-slate-800 text-white border-slate-800'
                  : 'bg-white text-slate-700 border-slate-200'
              }`}
            >
              NO — No Overtime Claim
            </button>
          </div>
        </div>

        {decision === 'YES' && (
          <>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Requested Overtime Hours</label>
                <input
                  type="number"
                  step="0.25"
                  min="0.25"
                  required
                  value={requestedHours}
                  onChange={(e) => setRequestedHours(e.target.value)}
                  className="w-full px-3 py-2 font-mono border border-slate-200 rounded-lg"
                />
              </div>
              <div>
                <label className="block font-medium text-slate-700 mb-1">System Verified Extra Time</label>
                <input
                  type="text"
                  readOnly
                  value={`${verifiedHours} hrs`}
                  className="w-full px-3 py-2 font-mono bg-slate-50 border border-slate-200 rounded-lg text-slate-600"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Reason / Work Completed *</label>
              <textarea
                rows={3}
                required
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Describe tasks performed during overtime..."
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg"
              />
            </div>
          </>
        )}

        <div className="flex justify-end gap-2 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 border border-slate-200 rounded-lg"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg"
          >
            {submitting ? 'Submitting...' : 'Confirm'}
          </button>
        </div>
      </form>
    </div>
  );
}

export function OvertimeApprovalPage({
  actor,
  employees,
  overtimeRequests,
  onReload,
  onNotify,
}: {
  actor: UserProfile;
  employees: Employee[];
  overtimeRequests: OvertimeRequest[];
  onReload: () => void;
  onNotify: (type: 'success' | 'error', title: string, desc?: string) => void;
}) {
  const [reviewing, setReviewing] = useState<OvertimeRequest | null>(null);
  const [approvedHrs, setApprovedHrs] = useState('0');
  const [remarks, setRemarks] = useState('');

  function openReview(req: OvertimeRequest) {
    setReviewing(req);
    setApprovedHrs(String(Math.min(req.requested_hours, req.verified_hours || req.requested_hours)));
    setRemarks(req.admin_remarks ?? '');
  }

  async function submitDecision(decision: 'APPROVED' | 'REJECTED') {
    if (!reviewing) return;
    const emp = employees.find((e) => e.id === reviewing.employee_id);
    const baseHourly = emp
      ? emp.overtime_rate > 0
        ? emp.overtime_rate
        : emp.hourly_rate > 0
        ? emp.hourly_rate
        : emp.daily_rate / 8
      : 100;
    const otRate = Number((baseHourly * 1.25).toFixed(2));
    try {
      await dataService.reviewOvertimeRequest(
        actor,
        reviewing,
        decision,
        Number(approvedHrs) || 0,
        otRate,
        remarks.trim() || (decision === 'APPROVED' ? 'Approved' : 'Rejected')
      );
      onNotify('success', `Overtime ${decision}`, `Updated overtime request for ${emp?.full_name}.`);
      setReviewing(null);
      onReload();
    } catch (err) {
      onNotify('error', 'Action failed', (err as Error).message);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-900">Overtime Approval Management</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Only approved overtime hours are included in payroll calculations.
        </p>
      </div>

      {overtimeRequests.length === 0 ? (
        <EmptyState
          title="No overtime requests"
          description="Submitted employee overtime requests (YES/NO) will appear here for review."
        />
      ) : (
        <div className="bg-white border border-slate-200 rounded-lg p-4 overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 font-medium">
                <th className="py-2.5 pr-3">Employee</th>
                <th className="py-2.5 px-3">Work Date</th>
                <th className="py-2.5 px-3">In / Actual Out</th>
                <th className="py-2.5 px-3">YES/NO</th>
                <th className="py-2.5 px-3 text-right">Req / Ver Hrs</th>
                <th className="py-2.5 px-3 text-right">Est. Amount</th>
                <th className="py-2.5 px-3">Reason</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 pl-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {overtimeRequests.map((req) => {
                const emp = employees.find((e) => e.id === req.employee_id);
                const estHourly = emp ? (emp.overtime_rate || emp.hourly_rate || emp.daily_rate / 8) * 1.25 : 0;
                const estAmt = req.status === 'APPROVED' ? req.approved_amount : req.requested_hours * estHourly;
                return (
                  <tr key={req.id} className="hover:bg-slate-50">
                    <td className="py-3 pr-3">
                      <p className="font-semibold text-slate-900">{emp?.full_name ?? 'Employee'}</p>
                      <p className="font-mono text-slate-500">{emp?.employee_number}</p>
                    </td>
                    <td className="py-3 px-3 font-mono whitespace-nowrap">{formatManilaDate(req.work_date)}</td>
                    <td className="py-3 px-3 font-mono tabular-nums whitespace-nowrap">
                      {formatManilaTime(req.actual_time_in)} – {formatManilaTime(req.actual_time_out)}
                    </td>
                    <td className="py-3 px-3 font-mono font-semibold">{req.decision}</td>
                    <td className="py-3 px-3 font-mono tabular-nums text-right">
                      {req.requested_hours}h / {req.verified_hours}h
                    </td>
                    <td className="py-3 px-3 font-mono tabular-nums text-right">{formatPeso(estAmt)}</td>
                    <td className="py-3 px-3 max-w-xs truncate text-slate-600">{req.reason}</td>
                    <td className="py-3 px-3">
                      <StatusLabel label={req.status} />
                    </td>
                    <td className="py-3 pl-3 text-right">
                      {req.status === 'PENDING' ? (
                        <button
                          type="button"
                          onClick={() => openReview(req)}
                          className="px-2.5 py-1.5 text-xs font-medium text-blue-700 bg-blue-50 border border-blue-200 rounded-md hover:bg-blue-100"
                        >
                          Review
                        </button>
                      ) : (
                        <span className="text-slate-400">{req.admin_remarks || 'Reviewed'}</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {reviewing && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl max-w-md w-full p-6 space-y-4 shadow-lg">
            <h3 className="text-base font-bold text-slate-900">Review Overtime Request</h3>
            <div className="text-xs text-slate-600 space-y-1 bg-slate-50 p-3 rounded-lg border border-slate-200">
              <p>
                <strong>Requested:</strong> {reviewing.requested_hours} hrs · <strong>Verified from Time Out:</strong>{' '}
                {reviewing.verified_hours} hrs
              </p>
              <p>
                <strong>Reason:</strong> {reviewing.reason}
              </p>
            </div>
            <div className="text-xs">
              <label className="block font-medium text-slate-700 mb-1">Approved Hours</label>
              <input
                type="number"
                step="0.25"
                value={approvedHrs}
                onChange={(e) => setApprovedHrs(e.target.value)}
                className="w-full px-3 py-2 font-mono border border-slate-200 rounded-lg"
              />
            </div>
            <div className="text-xs">
              <label className="block font-medium text-slate-700 mb-1">Admin Remarks / Reason</label>
              <input
                type="text"
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
                placeholder="Approval or rejection remarks..."
                className="w-full px-3 py-2 border border-slate-200 rounded-lg"
              />
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setReviewing(null)}
                className="px-3 py-2 text-xs font-medium text-slate-700 border border-slate-200 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => submitDecision('REJECTED')}
                className="px-3 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg inline-flex items-center gap-1"
              >
                <X className="w-3.5 h-3.5" />
                Reject
              </button>
              <button
                type="button"
                onClick={() => submitDecision('APPROVED')}
                className="px-3 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg inline-flex items-center gap-1"
              >
                <Check className="w-3.5 h-3.5" />
                Approve
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export function MyOvertimePage({
  actor,
  employee,
  attendance,
  overtimeRequests,
  onReload,
  onNotify,
}: {
  actor: UserProfile;
  employee: Employee | null;
  attendance: AttendanceRecord[];
  overtimeRequests: OvertimeRequest[];
  onReload: () => void;
  onNotify: (type: 'success' | 'error', title: string, desc?: string) => void;
}) {
  const [otModalAtt, setOtModalAtt] = useState<AttendanceRecord | null>(null);
  const myRequests = overtimeRequests.filter((o) => o.employee_id === employee?.id);
  const myAttendance = attendance.filter((a) => a.employee_id === employee?.id && a.actual_time_out);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900">My Overtime</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Submit YES/NO overtime claims beside completed time records and track approvals.
          </p>
        </div>
      </div>

      {employee && myAttendance.length > 0 && (
        <div className="bg-white border border-slate-200 rounded-lg p-4 space-y-3">
          <h2 className="text-sm font-semibold text-slate-900">Eligible Completed Time Records</h2>
          <div className="divide-y divide-slate-100">
            {myAttendance.slice(0, 5).map((att) => {
              const existing = myRequests.find((r) => r.work_date === att.work_date);
              return (
                <div key={att.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                  <div>
                    <span className="font-mono font-semibold text-slate-900">{formatManilaDate(att.work_date)}</span>
                    <span className="text-slate-500 ml-3 font-mono tabular-nums">
                      {formatManilaTime(att.actual_time_in)} – {formatManilaTime(att.actual_time_out)}
                    </span>
                  </div>
                  {existing ? (
                    <StatusLabel label={existing.status} />
                  ) : (
                    <button
                      type="button"
                      onClick={() => setOtModalAtt(att)}
                      className="px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 border border-blue-200 rounded-lg hover:bg-blue-100 inline-flex items-center gap-1"
                    >
                      <Clock className="w-3.5 h-3.5" />
                      Overtime Request
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {myRequests.length === 0 ? (
        <EmptyState
          title="No overtime requests submitted"
          description="Use the Overtime Request action beside any completed time record."
        />
      ) : (
        <div className="bg-white border border-slate-200 rounded-lg p-4 overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 font-medium">
                <th className="py-2.5 pr-3">Date</th>
                <th className="py-2.5 px-3">YES / NO</th>
                <th className="py-2.5 px-3 text-right">Requested</th>
                <th className="py-2.5 px-3 text-right">Actual Verified</th>
                <th className="py-2.5 px-3 text-right">Approved Hrs</th>
                <th className="py-2.5 px-3 text-right">Approved Amount</th>
                <th className="py-2.5 px-3">Reason</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 pl-3">Admin Remarks</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {myRequests.map((r) => (
                <tr key={r.id}>
                  <td className="py-2.5 pr-3 font-mono">{formatManilaDate(r.work_date)}</td>
                  <td className="py-2.5 px-3 font-mono font-semibold">{r.decision}</td>
                  <td className="py-2.5 px-3 font-mono tabular-nums text-right">{r.requested_hours}h</td>
                  <td className="py-2.5 px-3 font-mono tabular-nums text-right">{r.verified_hours}h</td>
                  <td className="py-2.5 px-3 font-mono tabular-nums text-right">{r.approved_hours}h</td>
                  <td className="py-2.5 px-3 font-mono tabular-nums text-right font-semibold">
                    {formatPeso(r.approved_amount)}
                  </td>
                  <td className="py-2.5 px-3 text-slate-600">{r.reason}</td>
                  <td className="py-2.5 px-3">
                    <StatusLabel label={r.status} />
                  </td>
                  <td className="py-2.5 pl-3 text-slate-500">{r.admin_remarks || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {otModalAtt && employee && (
        <OvertimeRequestModal
          actor={actor}
          employee={employee}
          attendance={otModalAtt}
          onClose={() => setOtModalAtt(null)}
          onSubmitted={onReload}
          onNotify={onNotify}
        />
      )}
    </div>
  );
}
