import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import { UserPlus, Upload, Download, FileSpreadsheet, CheckCircle2, AlertTriangle } from 'lucide-react';
import { dataService } from '../../services/dataService';
import { toManilaDateString } from '../../lib/date/manila';
import type {
  CompanySettings,
  Employee,
  EmploymentStatus,
  EmploymentType,
  SalaryType,
  Schedule,
  UserProfile,
} from '../../types/database';

const WEEKDAYS = [
  { value: 0, label: 'Sun' },
  { value: 1, label: 'Mon' },
  { value: 2, label: 'Tue' },
  { value: 3, label: 'Wed' },
  { value: 4, label: 'Thu' },
  { value: 5, label: 'Fri' },
  { value: 6, label: 'Sat' },
];

interface ParsedBulkEmployeeRow {
  rowNum: number;
  employee_number: string;
  full_name: string;
  position: string;
  department: string;
  contact_number: string;
  address: string;
  email: string;
  date_hired: string;
  employment_type: EmploymentType;
  employment_status: EmploymentStatus;
  rest_days: number[];
  salary_type: SalaryType;
  daily_rate: number;
  hourly_rate: number;
  monthly_rate: number;
  overtime_rate: number;
  meal_allowance: number;
  transport_allowance: number;
  other_allowances: number;
  sss_share: number;
  sss_share_remarks: string;
  phic_share: number;
  phic_share_remarks: string;
  pagibig_share: number;
  sss_loan: number;
  pagibig_loan: number;
  coop_share: number;
  coop_loan: number;
  donation: number;
  cash_advance: number;
  pin?: string;
  error?: string;
}

export function RegisterEmployeePage({
  actor,
  company,
  employees,
  schedules,
  onSuccess,
  onNotify,
}: {
  actor: UserProfile;
  company: CompanySettings;
  employees: Employee[];
  schedules: Schedule[];
  onSuccess: () => void;
  onNotify: (type: 'success' | 'error', title: string, desc?: string) => void;
}) {
  // Employee Number starts blank per requirement
  const [employeeNumber, setEmployeeNumber] = useState('');
  const [firstName, setFirstName] = useState('');
  const [middleInitial, setMiddleInitial] = useState('');
  const [lastName, setLastName] = useState('');
  const [position, setPosition] = useState('');
  const [department, setDepartment] = useState('Operations');
  const [contactNumber, setContactNumber] = useState('');
  const [address, setAddress] = useState('');
  const [email, setEmail] = useState('');
  const [dateHired, setDateHired] = useState(() => toManilaDateString());
  const [employmentType, setEmploymentType] = useState<EmploymentType>('REGULAR');
  const [employmentStatus, setEmploymentStatus] = useState<EmploymentStatus>('ACTIVE');
  const [scheduleId, setScheduleId] = useState(company.default_schedule_id ?? schedules[0]?.id ?? '');
  const [restDays, setRestDays] = useState<number[]>(company.default_rest_days ?? [0]);
  const [salaryType, setSalaryType] = useState<SalaryType>('DAILY');
  const [dailyRate, setDailyRate] = useState('800');
  const [hourlyRate, setHourlyRate] = useState('100');
  const [monthlyRate, setMonthlyRate] = useState('0');
  const [overtimeRate, setOvertimeRate] = useState('100');
  const [mealAllowance, setMealAllowance] = useState('0');
  const [transportAllowance, setTransportAllowance] = useState('0');
  const [otherAllowances, setOtherAllowances] = useState('0');

  // Itemized Deductions & Remarks
  const [sssShare, setSssShare] = useState('0');
  const [sssShareRemarks, setSssShareRemarks] = useState('');
  const [phicShare, setPhicShare] = useState('0');
  const [phicShareRemarks, setPhicShareRemarks] = useState('');
  const [pagibigShare, setPagibigShare] = useState('0');
  const [sssLoan, setSssLoan] = useState('0');
  const [pagibigLoan, setPagibigLoan] = useState('0');
  const [coopShare, setCoopShare] = useState('0');
  const [coopLoan, setCoopLoan] = useState('0');
  const [donation, setDonation] = useState('0');
  const [cashAdvance, setCashAdvance] = useState('0');

  const [attendancePin, setAttendancePin] = useState('');
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Mass Upload State
  const [bulkRows, setBulkRows] = useState<ParsedBulkEmployeeRow[]>([]);
  const [bulkImporting, setBulkImporting] = useState(false);

  const computedTotalDeductions =
    (Number(sssShare) || 0) +
    (Number(phicShare) || 0) +
    (Number(pagibigShare) || 0) +
    (Number(sssLoan) || 0) +
    (Number(pagibigLoan) || 0) +
    (Number(coopShare) || 0) +
    (Number(coopLoan) || 0) +
    (Number(donation) || 0) +
    (Number(cashAdvance) || 0);

  function toggleRestDay(d: number) {
    setRestDays((prev) => (prev.includes(d) ? prev.filter((x) => x !== d) : [...prev, d]));
  }

  function handlePhotoChange(file: File | null) {
    setPhotoFile(file);
    if (!file) {
      setPhotoPreview(null);
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setPhotoPreview(String(reader.result));
    reader.readAsDataURL(file);
  }

  function composeFullName(namePart: string, miPart: string, lastPart: string): string {
    const cleanName = namePart.trim();
    const rawMi = miPart.trim().replace(/\.+$/, '');
    const cleanMi = rawMi ? `${rawMi}.` : '';
    const cleanLast = lastPart.trim();
    return [cleanName, cleanMi, cleanLast].filter(Boolean).join(' ');
  }

  function downloadMassTemplate(format: 'xlsx' | 'csv') {
    const sample = [
      {
        employee_number: 'EMP-2026-0101',
        first_name: 'Juan',
        middle_initial: 'D',
        last_name: 'Dela Cruz',
        position: 'Auto Parts Specialist',
        department: 'Operations',
        contact_number: '+63 917 111 2233',
        address: 'Makati City, Metro Manila',
        email: 'juan.delacruz@company.ph',
        date_hired: toManilaDateString(),
        employment_type: 'REGULAR',
        employment_status: 'ACTIVE',
        rest_days: '0',
        salary_type: 'DAILY',
        daily_rate: 850,
        hourly_rate: 106.25,
        monthly_rate: 0,
        overtime_rate: 106.25,
        meal_allowance: 500,
        transport_allowance: 500,
        other_allowances: 0,
        sss_share: 300,
        sss_share_remarks: 'PARTIAL-NOV',
        phic_share: 200,
        phic_share_remarks: 'PARTIAL-NOV',
        pagibig_share: 100,
        sss_loan: 0,
        pagibig_loan: 0,
        coop_share: 100,
        coop_loan: 0,
        donation: 0,
        cash_advance: 0,
        pin: '',
      },
    ];
    const ws = XLSX.utils.json_to_sheet(sample);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Employees_Template');
    if (format === 'csv') {
      const csv = XLSX.utils.sheet_to_csv(ws);
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'PayLedger_Employee_Mass_Upload_Template.csv';
      a.click();
      URL.revokeObjectURL(url);
    } else {
      XLSX.writeFile(wb, 'PayLedger_Employee_Mass_Upload_Template.xlsx');
    }
  }

  async function handleMassUploadFile(file: File | null) {
    if (!file) return;
    try {
      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(buffer, { type: 'array' });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const rawRows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: '' });

      const existingNumbers = new Set(employees.map((e) => e.employee_number.trim().toUpperCase()));
      const seenInFile = new Set<string>();

      const parsed: ParsedBulkEmployeeRow[] = rawRows.map((raw, idx) => {
        const empNum = String(raw.employee_number ?? raw['Employee Number'] ?? '').trim().toUpperCase();
        const fName = String(raw.first_name ?? raw['First Name'] ?? raw['Name'] ?? '').trim();
        const mInit = String(raw.middle_initial ?? raw['Middle Initial'] ?? '').trim();
        const lName = String(raw.last_name ?? raw['Last Name'] ?? '').trim();
        const combinedFromParts = composeFullName(fName, mInit, lName);
        const name = combinedFromParts || String(raw.full_name ?? raw['Full Name'] ?? '').trim();
        const pos = String(raw.position ?? raw['Position'] ?? '').trim();
        const dept = String(raw.department ?? raw['Department'] ?? 'Operations').trim() || 'Operations';

        const restDaysRaw = String(raw.rest_days ?? '0');
        const parsedRest = restDaysRaw
          .split(/[,;\s]+/)
          .map((x) => Number(x.trim()))
          .filter((n) => !Number.isNaN(n) && n >= 0 && n <= 6);

        const salTypeRaw = String(raw.salary_type ?? 'DAILY').trim().toUpperCase();
        const salType: SalaryType =
          salTypeRaw === 'HOURLY' || salTypeRaw === 'MONTHLY' ? salTypeRaw : 'DAILY';

        const empTypeRaw = String(raw.employment_type ?? 'REGULAR').trim().toUpperCase();
        const empType: EmploymentType =
          empTypeRaw === 'PROBATIONARY' || empTypeRaw === 'CONTRACTUAL' || empTypeRaw === 'PART_TIME'
            ? empTypeRaw
            : 'REGULAR';

        const empStatusRaw = String(raw.employment_status ?? 'ACTIVE').trim().toUpperCase();
        const empStatus: EmploymentStatus =
          empStatusRaw === 'INACTIVE' || empStatusRaw === 'RESIGNED' || empStatusRaw === 'TERMINATED'
            ? empStatusRaw
            : 'ACTIVE';

        let error: string | undefined;
        if (!empNum) error = 'Missing Employee Number';
        else if (!name) error = 'Missing Full Name';
        else if (!pos) error = 'Missing Position';
        else if (existingNumbers.has(empNum)) error = 'Duplicate (already exists)';
        else if (seenInFile.has(empNum)) error = 'Duplicate inside file';

        if (empNum) seenInFile.add(empNum);

        return {
          rowNum: idx + 2,
          employee_number: empNum,
          full_name: name,
          position: pos,
          department: dept,
          contact_number: String(raw.contact_number ?? '').trim(),
          address: String(raw.address ?? '').trim(),
          email: String(raw.email ?? '').trim(),
          date_hired: String(raw.date_hired ?? '').trim() || toManilaDateString(),
          employment_type: empType,
          employment_status: empStatus,
          rest_days: parsedRest.length > 0 ? parsedRest : [0],
          salary_type: salType,
          daily_rate: Number(raw.daily_rate) || 0,
          hourly_rate: Number(raw.hourly_rate) || 0,
          monthly_rate: Number(raw.monthly_rate) || 0,
          overtime_rate: Number(raw.overtime_rate) || 0,
          meal_allowance: Number(raw.meal_allowance) || 0,
          transport_allowance: Number(raw.transport_allowance) || 0,
          other_allowances: Number(raw.other_allowances) || 0,
          sss_share: Number(raw.sss_share) || 0,
          sss_share_remarks: String(raw.sss_share_remarks ?? '').trim(),
          phic_share: Number(raw.phic_share) || 0,
          phic_share_remarks: String(raw.phic_share_remarks ?? '').trim(),
          pagibig_share: Number(raw.pagibig_share) || 0,
          sss_loan: Number(raw.sss_loan) || 0,
          pagibig_loan: Number(raw.pagibig_loan) || 0,
          coop_share: Number(raw.coop_share) || 0,
          coop_loan: Number(raw.coop_loan) || 0,
          donation: Number(raw.donation) || 0,
          cash_advance: Number(raw.cash_advance) || 0,
          pin: String(raw.pin ?? '').trim() || undefined,
          error,
        };
      });

      setBulkRows(parsed);
      if (parsed.length === 0) {
        onNotify('error', 'Empty file', 'No rows were found in the uploaded spreadsheet.');
      }
    } catch (err) {
      onNotify('error', 'Failed to parse spreadsheet', (err as Error).message);
    }
  }

  async function handleConfirmBulkImport() {
    const validRows = bulkRows.filter((r) => !r.error);
    if (validRows.length === 0) {
      onNotify('error', 'No valid rows', 'Fix or remove invalid rows before importing.');
      return;
    }
    setBulkImporting(true);
    try {
      const payload = validRows.map((r) => ({
        input: {
          employee_number: r.employee_number,
          full_name: r.full_name,
          photo_url: null,
          position: r.position,
          department: r.department,
          contact_number: r.contact_number,
          address: r.address,
          email: r.email,
          date_hired: r.date_hired,
          employment_type: r.employment_type,
          employment_status: r.employment_status,
          schedule_id: company.default_schedule_id ?? schedules[0]?.id ?? null,
          rest_days: r.rest_days,
          salary_type: r.salary_type,
          daily_rate: r.daily_rate,
          hourly_rate: r.hourly_rate,
          monthly_rate: r.monthly_rate,
          overtime_rate: r.overtime_rate,
          meal_allowance: r.meal_allowance,
          transport_allowance: r.transport_allowance,
          other_allowances: r.other_allowances,
          default_deductions:
            r.sss_share +
            r.phic_share +
            r.pagibig_share +
            r.sss_loan +
            r.pagibig_loan +
            r.coop_share +
            r.coop_loan +
            r.donation +
            r.cash_advance,
          sss_share: r.sss_share,
          sss_share_remarks: r.sss_share_remarks,
          phic_share: r.phic_share,
          phic_share_remarks: r.phic_share_remarks,
          pagibig_share: r.pagibig_share,
          sss_loan: r.sss_loan,
          pagibig_loan: r.pagibig_loan,
          coop_share: r.coop_share,
          coop_loan: r.coop_loan,
          donation: r.donation,
          cash_advance: r.cash_advance,
        },
        pin: r.pin,
      }));
      const res = await dataService.createEmployeesBulk(actor, payload);
      onNotify(
        'success',
        `Imported ${res.created.length} Employee(s)`,
        res.skipped.length > 0 ? `${res.skipped.length} row(s) skipped.` : 'All valid employees registered.'
      );
      setBulkRows([]);
      onSuccess();
    } catch (err) {
      onNotify('error', 'Bulk import failed', (err as Error).message);
    } finally {
      setBulkImporting(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const composedFullName = composeFullName(firstName, middleInitial, lastName);
    if (!employeeNumber.trim() || !firstName.trim() || !lastName.trim() || !position.trim()) {
      onNotify(
        'error',
        'Missing required fields',
        'Employee Number, Name, Last Name, and Position are required.'
      );
      return;
    }
    setSubmitting(true);
    try {
      let photoUrl: string | null = null;
      if (photoFile) {
        photoUrl = await dataService.uploadEmployeePhoto(employeeNumber.trim(), photoFile);
      }

      const emp = await dataService.createEmployee(
        actor,
        {
          employee_number: employeeNumber.trim().toUpperCase(),
          full_name: composedFullName,
          photo_url: photoUrl,
          position: position.trim(),
          department: department.trim(),
          contact_number: contactNumber.trim(),
          address: address.trim(),
          email: email.trim(),
          date_hired: dateHired,
          employment_type: employmentType,
          employment_status: employmentStatus,
          schedule_id: scheduleId || null,
          rest_days: restDays,
          salary_type: salaryType,
          daily_rate: Number(dailyRate) || 0,
          hourly_rate: Number(hourlyRate) || 0,
          monthly_rate: Number(monthlyRate) || 0,
          overtime_rate: Number(overtimeRate) || 0,
          meal_allowance: Number(mealAllowance) || 0,
          transport_allowance: Number(transportAllowance) || 0,
          other_allowances: Number(otherAllowances) || 0,
          default_deductions: computedTotalDeductions,
          sss_share: Number(sssShare) || 0,
          sss_share_remarks: sssShareRemarks.trim(),
          phic_share: Number(phicShare) || 0,
          phic_share_remarks: phicShareRemarks.trim(),
          pagibig_share: Number(pagibigShare) || 0,
          sss_loan: Number(sssLoan) || 0,
          pagibig_loan: Number(pagibigLoan) || 0,
          coop_share: Number(coopShare) || 0,
          coop_loan: Number(coopLoan) || 0,
          donation: Number(donation) || 0,
          cash_advance: Number(cashAdvance) || 0,
        },
        attendancePin.trim() || undefined
      );

      onNotify('success', 'Employee Registered', `${emp.full_name} (${emp.employee_number}) is ready for attendance.`);
      onSuccess();
    } catch (err) {
      onNotify('error', 'Registration failed', (err as Error).message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="max-w-5xl space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100">Register Employee</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Register an individual employee or mass upload multiple employees using the Excel/CSV template.
          </p>
        </div>
      </div>

      {/* Mass Upload & Template Card */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shadow-sm dark:shadow-lg dark:shadow-black/30 rounded-xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              Mass Employee Upload &amp; Template
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Download the template, fill out employee numbers, rates, and statutory deductions, then upload `.xlsx` or `.csv`.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => downloadMassTemplate('xlsx')}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 shadow-2xs"
            >
              <Download className="w-3.5 h-3.5" />
              Mass Upload Template (.xlsx)
            </button>
            <button
              type="button"
              onClick={() => downloadMassTemplate('csv')}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 shadow-2xs"
            >
              <Download className="w-3.5 h-3.5" />
              Template (.csv)
            </button>
            <label className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs cursor-pointer">
              <Upload className="w-3.5 h-3.5" />
              Mass Upload (.xlsx / .csv)
              <input
                type="file"
                accept=".xlsx,.xls,.csv"
                className="hidden"
                onChange={(e) => {
                  handleMassUploadFile(e.target.files?.[0] ?? null);
                  e.target.value = '';
                }}
              />
            </label>
          </div>
        </div>

        {bulkRows.length > 0 && (
          <div className="space-y-3 pt-2 border-t border-slate-200 dark:border-slate-700">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <span className="font-medium text-slate-700 dark:text-slate-300">
                Parsed {bulkRows.length} row(s) — {bulkRows.filter((r) => !r.error).length} valid,{' '}
                {bulkRows.filter((r) => r.error).length} invalid
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setBulkRows([])}
                  className="px-3 py-1.5 text-xs font-medium text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 rounded-lg"
                >
                  Clear Preview
                </button>
                <button
                  type="button"
                  disabled={bulkImporting || bulkRows.filter((r) => !r.error).length === 0}
                  onClick={handleConfirmBulkImport}
                  className="px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 rounded-lg"
                >
                  {bulkImporting ? 'Importing...' : `Import ${bulkRows.filter((r) => !r.error).length} Employee(s)`}
                </button>
              </div>
            </div>
            <div className="overflow-x-auto max-h-60 border border-slate-200 dark:border-slate-700 rounded-lg">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300">
                    <th className="py-2 px-2.5 border-r border-slate-200 dark:border-slate-700">Row</th>
                    <th className="py-2 px-2.5 border-r border-slate-200 dark:border-slate-700">Employee #</th>
                    <th className="py-2 px-2.5 border-r border-slate-200 dark:border-slate-700">Full Name</th>
                    <th className="py-2 px-2.5 border-r border-slate-200 dark:border-slate-700">Position / Dept</th>
                    <th className="py-2 px-2.5 border-r border-slate-200 dark:border-slate-700">Salary</th>
                    <th className="py-2 px-2.5">Validation</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                  {bulkRows.map((row) => (
                    <tr key={`${row.rowNum}-${row.employee_number}`}>
                      <td className="py-1.5 px-2.5 font-mono border-r border-slate-200 dark:border-slate-700">{row.rowNum}</td>
                      <td className="py-1.5 px-2.5 font-mono font-semibold border-r border-slate-200 dark:border-slate-700">
                        {row.employee_number || '—'}
                      </td>
                      <td className="py-1.5 px-2.5 border-r border-slate-200 dark:border-slate-700">{row.full_name || '—'}</td>
                      <td className="py-1.5 px-2.5 border-r border-slate-200 dark:border-slate-700">
                        {row.position} · {row.department}
                      </td>
                      <td className="py-1.5 px-2.5 font-mono border-r border-slate-200 dark:border-slate-700">
                        {row.salary_type} ({row.daily_rate || row.monthly_rate || row.hourly_rate})
                      </td>
                      <td className="py-1.5 px-2.5">
                        {row.error ? (
                          <span className="inline-flex items-center gap-1 text-rose-600 dark:text-rose-400 font-medium">
                            <AlertTriangle className="w-3.5 h-3.5" />
                            {row.error}
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-400 font-medium">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            Ready
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      <form
        onSubmit={handleSubmit}
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shadow-sm dark:shadow-lg dark:shadow-black/30 rounded-xl p-6 space-y-6"
      >
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-center pb-6 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-4 sm:col-span-2">
            <div className="w-16 h-16 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 flex items-center justify-center overflow-hidden shrink-0">
              {photoPreview ? (
                <img src={photoPreview} alt="Preview" className="w-full h-full object-cover" />
              ) : (
                <span className="text-xs text-slate-400 font-medium">Photo</span>
              )}
            </div>
            <div>
              <label className="inline-flex items-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 cursor-pointer">
                <Upload className="w-3.5 h-3.5" />
                Upload Employee Photo
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => handlePhotoChange(e.target.files?.[0] ?? null)}
                />
              </label>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Stored privately in Supabase Storage (employee-photos).
              </p>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Employee Number *</label>
            <input
              type="text"
              required
              value={employeeNumber}
              onChange={(e) => setEmployeeNumber(e.target.value.toUpperCase())}
              placeholder="Enter Employee Number (blank by default)"
              className="w-full px-3 py-2 text-sm font-mono font-semibold border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-12 gap-4">
          <div className="sm:col-span-4">
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Name (First Name) *
            </label>
            <input
              type="text"
              required
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
              placeholder="e.g. Maria"
              className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
            />
          </div>
          <div className="sm:col-span-2">
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Middle Initial
            </label>
            <input
              type="text"
              maxLength={4}
              value={middleInitial}
              onChange={(e) => setMiddleInitial(e.target.value.toUpperCase())}
              placeholder="e.g. C."
              className="w-full px-3 py-2 text-sm font-mono uppercase border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
            />
          </div>
          <div className="sm:col-span-3">
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Last Name *
            </label>
            <input
              type="text"
              required
              value={lastName}
              onChange={(e) => setLastName(e.target.value)}
              placeholder="e.g. Santos"
              className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
            />
          </div>
          <div className="sm:col-span-3">
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Date Hired *</label>
            <input
              type="date"
              required
              value={dateHired}
              onChange={(e) => setDateHired(e.target.value)}
              className="w-full px-3 py-2 text-sm font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Position *</label>
            <input
              type="text"
              required
              value={position}
              onChange={(e) => setPosition(e.target.value)}
              placeholder="e.g. Operations Specialist"
              className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Department *</label>
            <input
              type="text"
              required
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Contact Number</label>
            <input
              type="text"
              value={contactNumber}
              onChange={(e) => setContactNumber(e.target.value)}
              placeholder="+63 917 000 0000"
              className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="employee@company.ph"
              className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
            />
          </div>
          <div className="sm:col-span-2">
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Home Address</label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Street, Barangay, City"
              className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Employment Type</label>
            <select
              value={employmentType}
              onChange={(e) => setEmploymentType(e.target.value as EmploymentType)}
              className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
            >
              <option value="REGULAR">Regular</option>
              <option value="PROBATIONARY">Probationary</option>
              <option value="CONTRACTUAL">Contractual</option>
              <option value="PART_TIME">Part Time</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Employment Status</label>
            <select
              value={employmentStatus}
              onChange={(e) => setEmploymentStatus(e.target.value as EmploymentStatus)}
              className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
            >
              <option value="ACTIVE">Active</option>
              <option value="INACTIVE">Inactive</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Assigned Schedule</label>
            <select
              value={scheduleId}
              onChange={(e) => setScheduleId(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
            >
              {schedules.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-2">
            Assigned Rest Day(s) — Sunday is not automatic; select employee&apos;s rest day(s)
          </label>
          <div className="flex flex-wrap gap-2">
            {WEEKDAYS.map((w) => {
              const active = restDays.includes(w.value);
              return (
                <button
                  key={w.value}
                  type="button"
                  onClick={() => toggleRestDay(w.value)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors ${
                    active
                      ? 'bg-blue-600 text-white border-blue-600'
                      : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700'
                  }`}
                >
                  {w.label}
                </button>
              );
            })}
          </div>
        </div>

        <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-4">
          <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            Compensation &amp; Allowances (₱ PHP)
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Salary Type</label>
              <select
                value={salaryType}
                onChange={(e) => setSalaryType(e.target.value as SalaryType)}
                className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
              >
                <option value="DAILY">Daily Paid</option>
                <option value="HOURLY">Hourly Paid</option>
                <option value="MONTHLY">Monthly Paid</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Daily Rate (₱)</label>
              <input
                type="number"
                step="0.01"
                value={dailyRate}
                onChange={(e) => setDailyRate(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Hourly Rate (₱)</label>
              <input
                type="number"
                step="0.01"
                value={hourlyRate}
                onChange={(e) => setHourlyRate(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Monthly Rate (₱)</label>
              <input
                type="number"
                step="0.01"
                value={monthlyRate}
                onChange={(e) => setMonthlyRate(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Overtime Base Rate (₱/hr)
              </label>
              <input
                type="number"
                step="0.01"
                value={overtimeRate}
                onChange={(e) => setOvertimeRate(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Meal Allowance (₱)</label>
              <input
                type="number"
                step="0.01"
                value={mealAllowance}
                onChange={(e) => setMealAllowance(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Transport Allowance (₱)
              </label>
              <input
                type="number"
                step="0.01"
                value={transportAllowance}
                onChange={(e) => setTransportAllowance(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Other Allowances (₱)
              </label>
              <input
                type="number"
                step="0.01"
                value={otherAllowances}
                onChange={(e) => setOtherAllowances(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
              />
            </div>
          </div>

          {/* Itemized Deductions & Remarks */}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-700 dark:text-slate-300">
                Recurring Deductions &amp; Statutory Shares (₱ PHP)
              </h4>
              <span className="text-xs font-mono font-semibold text-rose-700 dark:text-rose-400">
                Total: ₱{computedTotalDeductions.toFixed(2)}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
              <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-800/50 space-y-2">
                <label className="block font-medium text-slate-700 dark:text-slate-300">SSS Share (₱)</label>
                <input
                  type="number"
                  step="0.01"
                  value={sssShare}
                  onChange={(e) => setSssShare(e.target.value)}
                  className="w-full px-3 py-1.5 font-mono border border-slate-200 dark:border-slate-700 rounded-md bg-white dark:bg-slate-900"
                />
                <input
                  type="text"
                  value={sssShareRemarks}
                  onChange={(e) => setSssShareRemarks(e.target.value)}
                  placeholder="SSS Remarks (e.g. PARTIAL-NOV)"
                  className="w-full px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded-md bg-white dark:bg-slate-900"
                />
              </div>

              <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-800/50 space-y-2">
                <label className="block font-medium text-slate-700 dark:text-slate-300">PHIC Share (₱)</label>
                <input
                  type="number"
                  step="0.01"
                  value={phicShare}
                  onChange={(e) => setPhicShare(e.target.value)}
                  className="w-full px-3 py-1.5 font-mono border border-slate-200 dark:border-slate-700 rounded-md bg-white dark:bg-slate-900"
                />
                <input
                  type="text"
                  value={phicShareRemarks}
                  onChange={(e) => setPhicShareRemarks(e.target.value)}
                  placeholder="PHIC Remarks (e.g. PARTIAL-NOV)"
                  className="w-full px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded-md bg-white dark:bg-slate-900"
                />
              </div>

              <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-800/50 space-y-2">
                <label className="block font-medium text-slate-700 dark:text-slate-300">PAG-IBIG Share (₱)</label>
                <input
                  type="number"
                  step="0.01"
                  value={pagibigShare}
                  onChange={(e) => setPagibigShare(e.target.value)}
                  className="w-full px-3 py-1.5 font-mono border border-slate-200 dark:border-slate-700 rounded-md bg-white dark:bg-slate-900"
                />
                <label className="block font-medium text-slate-700 dark:text-slate-300 pt-1">Optional Kiosk PIN</label>
                <input
                  type="password"
                  value={attendancePin}
                  onChange={(e) => setAttendancePin(e.target.value)}
                  placeholder="Optional 4-6 digits"
                  className="w-full px-3 py-1.5 font-mono border border-slate-200 dark:border-slate-700 rounded-md bg-white dark:bg-slate-900"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">SSS Loan (₱)</label>
                <input
                  type="number"
                  step="0.01"
                  value={sssLoan}
                  onChange={(e) => setSssLoan(e.target.value)}
                  className="w-full px-3 py-2 font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
                />
              </div>
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Pag-ibig Loan (₱)</label>
                <input
                  type="number"
                  step="0.01"
                  value={pagibigLoan}
                  onChange={(e) => setPagibigLoan(e.target.value)}
                  className="w-full px-3 py-2 font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
                />
              </div>
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Coop Share (₱)</label>
                <input
                  type="number"
                  step="0.01"
                  value={coopShare}
                  onChange={(e) => setCoopShare(e.target.value)}
                  className="w-full px-3 py-2 font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
                />
              </div>
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Coop Loan (₱)</label>
                <input
                  type="number"
                  step="0.01"
                  value={coopLoan}
                  onChange={(e) => setCoopLoan(e.target.value)}
                  className="w-full px-3 py-2 font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
                />
              </div>
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Donation (₱)</label>
                <input
                  type="number"
                  step="0.01"
                  value={donation}
                  onChange={(e) => setDonation(e.target.value)}
                  className="w-full px-3 py-2 font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
                />
              </div>
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Cash Advance (₱)</label>
                <input
                  type="number"
                  step="0.01"
                  value={cashAdvance}
                  onChange={(e) => setCashAdvance(e.target.value)}
                  className="w-full px-3 py-2 font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
          <button
            type="submit"
            disabled={submitting}
            className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 rounded-lg shadow-xs"
          >
            <UserPlus className="w-4 h-4" />
            {submitting ? 'Saving Employee...' : 'Register Employee'}
          </button>
        </div>
      </form>
    </div>
  );
}
