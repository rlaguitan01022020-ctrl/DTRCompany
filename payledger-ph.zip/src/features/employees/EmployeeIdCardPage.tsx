import React, { useMemo, useState } from 'react';
import { Download, Printer, ShieldAlert, ShieldCheck, KeyRound } from 'lucide-react';
import { Avatar, StatusLabel } from '../../components/ui/Common';
import { formatManilaDate } from '../../lib/date/manila';
import { downloadEmployeeIdCardPng, exportEmployeeIdCardPdf } from '../../lib/export/exporters';
import { dataService } from '../../services/dataService';
import type {
  CompanySettings,
  Employee,
  EmployeeNumberCredential,
  UserProfile,
} from '../../types/database';

export function EmployeeIdCardPage({
  actor,
  company,
  employees,
  credentials,
  initialEmployeeId,
  onReload,
  onNotify,
}: {
  actor: UserProfile;
  company: CompanySettings;
  employees: Employee[];
  credentials: EmployeeNumberCredential[];
  initialEmployeeId?: string | null;
  onReload: () => void;
  onNotify: (type: 'success' | 'error', title: string, desc?: string) => void;
}) {
  const [selectedId, setSelectedId] = useState(initialEmployeeId || employees[0]?.id || '');
  const [newPin, setNewPin] = useState('');
  const [pinRequired, setPinRequired] = useState(false);

  const selectedEmp = useMemo(
    () => employees.find((e) => e.id === selectedId) ?? employees[0],
    [employees, selectedId]
  );

  const credential = useMemo(
    () => credentials.find((c) => c.employee_id === selectedEmp?.id),
    [credentials, selectedEmp]
  );

  async function handleStatusChange(status: 'ACTIVE' | 'SUSPENDED' | 'REVOKED') {
    if (!selectedEmp) return;
    try {
      await dataService.updateEmployeeCredential(actor, selectedEmp.id, {
        credential_status: status,
        revoked_reason: status === 'REVOKED' ? 'Revoked by administrator' : undefined,
      });
      onNotify('success', 'Credential Updated', `${selectedEmp.employee_number} set to ${status}.`);
      onReload();
    } catch (err) {
      onNotify('error', 'Failed to update credential', (err as Error).message);
    }
  }

  async function handleSavePin(e: React.FormEvent) {
    e.preventDefault();
    if (!selectedEmp) return;
    try {
      await dataService.updateEmployeeCredential(actor, selectedEmp.id, {
        pin_required: pinRequired,
        pin: newPin.trim() || undefined,
      });
      onNotify('success', 'Attendance PIN Policy Updated', `${selectedEmp.employee_number} PIN settings saved.`);
      setNewPin('');
      onReload();
    } catch (err) {
      onNotify('error', 'Failed to update PIN', (err as Error).message);
    }
  }

  if (!selectedEmp) {
    return <p className="text-sm text-slate-500">Register an employee first to generate ID cards.</p>;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 no-print">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Employee ID Card &amp; Number Credentials</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Official Employee Number ID Cards (printable, PNG, and PDF) with credential status control.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <select
            value={selectedEmp.id}
            onChange={(e) => setSelectedId(e.target.value)}
            className="px-3 py-2 text-xs font-medium border border-slate-200 rounded-lg bg-white"
          >
            {employees.map((e) => (
              <option key={e.id} value={e.id}>
                {e.employee_number} — {e.full_name}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Printable Employee ID Card Preview */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 space-y-5">
          <div className="flex items-center justify-between no-print">
            <h2 className="text-sm font-semibold text-slate-900">ID Card Preview</h2>
            <StatusLabel label={credential?.credential_status ?? 'ACTIVE'} />
          </div>

          <div className="max-w-md mx-auto border border-slate-300 rounded-xl overflow-hidden bg-white shadow-xs">
            <div className="bg-slate-900 text-white px-5 py-4 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5 min-w-0">
                {company.company_logo_url ? (
                  <img
                    src={company.company_logo_url}
                    alt={company.company_name}
                    referrerPolicy="no-referrer"
                    className="w-8 h-8 rounded object-cover"
                  />
                ) : (
                  <div className="w-8 h-8 rounded bg-blue-600 text-white font-bold flex items-center justify-center text-xs">
                    PL
                  </div>
                )}
                <div className="min-w-0">
                  <p className="text-sm font-bold truncate">{company.company_name}</p>
                  <p className="text-[11px] text-slate-300">Official Employee Identification</p>
                </div>
              </div>
            </div>

            <div className="p-5 flex items-start gap-4">
              <Avatar name={selectedEmp.full_name} src={selectedEmp.photo_url} size="xl" />
              <div className="min-w-0 flex-1">
                <h3 className="text-lg font-bold text-slate-900 truncate">{selectedEmp.full_name}</h3>
                <p className="text-xs font-medium text-slate-600 mt-0.5">{selectedEmp.position}</p>
                <p className="text-xs text-slate-500">{selectedEmp.department}</p>
                <p className="text-[11px] text-slate-500 mt-2">
                  Hired: {formatManilaDate(selectedEmp.date_hired)} · {selectedEmp.employment_type}
                </p>
              </div>
            </div>

            <div className="mx-5 mb-5 p-3.5 rounded-lg bg-blue-50 border border-blue-200">
              <p className="text-[10px] font-semibold tracking-wider text-blue-700 uppercase">
                Employee Number (Attendance ID)
              </p>
              <p className="text-2xl font-mono font-bold tracking-wider text-slate-900 mt-0.5">
                {selectedEmp.employee_number}
              </p>
            </div>

            <div className="px-5 py-2.5 bg-slate-50 border-t border-slate-200 text-[11px] text-slate-500 flex items-center justify-between">
              <span className="truncate">{company.company_address}</span>
              <span className="font-mono shrink-0">{company.contact_number}</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2 pt-2 no-print">
            <button
              type="button"
              onClick={() => downloadEmployeeIdCardPng(selectedEmp, company)}
              className="px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg inline-flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              Download PNG
            </button>
            <button
              type="button"
              onClick={() => exportEmployeeIdCardPdf(selectedEmp, company)}
              className="px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg inline-flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              Download PDF
            </button>
            <button
              type="button"
              onClick={() => window.print()}
              className="px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg inline-flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              Print ID Card
            </button>
          </div>
        </div>

        {/* Credential Access & Security Controls */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 space-y-6 no-print">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">Employee Number Credential Control</h3>
            <p className="text-xs text-slate-500 mt-1">
              Revoking or suspending immediately blocks Time In / Time Out at all terminals and kiosks.
            </p>
            <div className="flex flex-wrap gap-2 mt-4">
              <button
                type="button"
                onClick={() => handleStatusChange('ACTIVE')}
                className="px-3 py-2 text-xs font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg hover:bg-emerald-100 inline-flex items-center gap-1.5"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                Activate
              </button>
              <button
                type="button"
                onClick={() => handleStatusChange('SUSPENDED')}
                className="px-3 py-2 text-xs font-medium text-amber-800 bg-amber-50 border border-amber-200 rounded-lg hover:bg-amber-100"
              >
                Suspend
              </button>
              <button
                type="button"
                onClick={() => handleStatusChange('REVOKED')}
                className="px-3 py-2 text-xs font-medium text-rose-700 bg-rose-50 border border-rose-200 rounded-lg hover:bg-rose-100 inline-flex items-center gap-1.5"
              >
                <ShieldAlert className="w-3.5 h-3.5" />
                Revoke
              </button>
            </div>
          </div>

          <form onSubmit={handleSavePin} className="pt-5 border-t border-slate-100 space-y-3">
            <div className="flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-slate-500" />
              <h4 className="text-sm font-semibold text-slate-900">Optional Attendance PIN Verification</h4>
            </div>
            <label className="flex items-center gap-2 text-xs text-slate-700">
              <input
                type="checkbox"
                checked={pinRequired}
                onChange={(e) => setPinRequired(e.target.checked)}
                className="rounded border-slate-300"
              />
              Require PIN when punching with {selectedEmp.employee_number}
            </label>
            <input
              type="password"
              value={newPin}
              onChange={(e) => setNewPin(e.target.value)}
              placeholder="Set or update 4–6 digit PIN"
              className="w-full px-3 py-2 text-xs font-mono border border-slate-200 rounded-lg"
            />
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg"
            >
              Update PIN Settings
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
