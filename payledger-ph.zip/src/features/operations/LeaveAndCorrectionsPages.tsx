import React, { useState } from 'react';
import { CalendarDays, Check, X, Wrench } from 'lucide-react';
import { EmptyState, StatusLabel } from '../../components/ui/Common';
import {
  buildManilaTimestamp,
  enumerateDateRange,
  formatManilaDate,
  formatManilaTime,
  toManilaTime24,
} from '../../lib/date/manila';
import { dataService } from '../../services/dataService';
import type {
  AttendanceCorrection,
  AttendanceRecord,
  Employee,
  Holiday,
  LeaveRequest,
  Schedule,
  UserProfile,
} from '../../types/database';

export function LeaveManagementPage({
  actor,
  employees,
  leaveRequests,
  onReload,
  onNotify,
}: {
  actor: UserProfile;
  employees: Employee[];
  leaveRequests: LeaveRequest[];
  onReload: () => void;
  onNotify: (type: 'success' | 'error', title: string, desc?: string) => void;
}) {
  const canApprove = actor.role === 'SUPER_ADMIN' || actor.role === 'ADMIN' || actor.role === 'HR';
  const myEmp = employees.find((e) => e.id === actor.employee_id) ?? employees[0];

  const [employeeId, setEmployeeId] = useState(myEmp?.id ?? '');
  const [leaveType, setLeaveType] = useState('Vacation Leave');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [isPaid, setIsPaid] = useState(true);
  const [reason, setReason] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const visibleLeaves =
    actor.role === 'EMPLOYEE'
      ? leaveRequests.filter((l) => l.employee_id === actor.employee_id)
      : leaveRequests;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!employeeId || !startDate || !endDate || !reason.trim()) return;
    const totalDays = enumerateDateRange(startDate, endDate).length;
    setSubmitting(true);
    try {
      await dataService.submitLeaveRequest(actor, {
        employee_id: employeeId,
        leave_type: leaveType,
        start_date: startDate,
        end_date: endDate,
        total_days: totalDays,
        is_paid: isPaid,
        reason: reason.trim(),
        attachment_path: null,
      });
      setReason('');
      onNotify('success', 'Leave Request Submitted', `${totalDays} day(s) submitted for review.`);
      onReload();
    } catch (err) {
      onNotify('error', 'Failed to submit leave', (err as Error).message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-900">Leave Management</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Approved leave automatically reflects in Attendance Monitoring and Payroll (never marked as absent).
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <form onSubmit={handleSubmit} className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-5 space-y-3.5 text-xs">
          <h2 className="text-sm font-semibold text-slate-900">Submit Leave Request</h2>
          {canApprove && (
            <div>
              <label className="block font-medium text-slate-700 mb-1">Employee</label>
              <select
                value={employeeId}
                onChange={(e) => setEmployeeId(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-white"
              >
                {employees
                  .filter((e) => e.is_active)
                  .map((e) => (
                    <option key={e.id} value={e.id}>
                      {e.employee_number} — {e.full_name}
                    </option>
                  ))}
              </select>
            </div>
          )}
          <div>
            <label className="block font-medium text-slate-700 mb-1">Leave Type</label>
            <select
              value={leaveType}
              onChange={(e) => setLeaveType(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-white"
            >
              <option>Vacation Leave</option>
              <option>Sick Leave</option>
              <option>Emergency Leave</option>
              <option>Service Incentive Leave</option>
              <option>Leave Without Pay</option>
            </select>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Start Date</label>
              <input
                type="date"
                required
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 font-mono border border-slate-200 rounded-lg"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">End Date</label>
              <input
                type="date"
                required
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3 py-2 font-mono border border-slate-200 rounded-lg"
              />
            </div>
          </div>
          <label className="flex items-center gap-2 text-slate-700">
            <input
              type="checkbox"
              checked={isPaid}
              onChange={(e) => setIsPaid(e.target.checked)}
              className="rounded border-slate-300"
            />
            Paid Leave (eligible under company policy)
          </label>
          <div>
            <label className="block font-medium text-slate-700 mb-1">Reason *</label>
            <textarea
              rows={3}
              required
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Reason for leave..."
              className="w-full px-3 py-2 border border-slate-200 rounded-lg"
            />
          </div>
          <button
            type="submit"
            disabled={submitting}
            className="w-full py-2.5 px-4 font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg inline-flex items-center justify-center gap-1.5"
          >
            <CalendarDays className="w-3.5 h-3.5" />
            {submitting ? 'Submitting...' : 'Submit Leave Request'}
          </button>
        </form>

        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-xl p-5">
          <h2 className="text-sm font-semibold text-slate-900 mb-3">Leave History &amp; Approvals</h2>
          {visibleLeaves.length === 0 ? (
            <EmptyState title="No leave requests" description="Submitted leave requests appear here." />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 font-medium">
                    <th className="py-2 pr-3">Employee</th>
                    <th className="py-2 px-3">Type</th>
                    <th className="py-2 px-3">Dates</th>
                    <th className="py-2 px-3 text-right">Days</th>
                    <th className="py-2 px-3">Reason</th>
                    <th className="py-2 px-3">Status</th>
                    {canApprove && <th className="py-2 pl-3 text-right">Action</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {visibleLeaves.map((l) => {
                    const emp = employees.find((e) => e.id === l.employee_id);
                    return (
                      <tr key={l.id}>
                        <td className="py-2.5 pr-3">
                          <p className="font-semibold text-slate-900">{emp?.full_name ?? 'Employee'}</p>
                          <p className="font-mono text-slate-500">{emp?.employee_number}</p>
                        </td>
                        <td className="py-2.5 px-3">
                          {l.leave_type}
                          <span className="block text-[10px] text-slate-500">{l.is_paid ? 'Paid' : 'Unpaid'}</span>
                        </td>
                        <td className="py-2.5 px-3 font-mono whitespace-nowrap">
                          {formatManilaDate(l.start_date)} – {formatManilaDate(l.end_date)}
                        </td>
                        <td className="py-2.5 px-3 font-mono tabular-nums text-right">{l.total_days}</td>
                        <td className="py-2.5 px-3 text-slate-600 max-w-xs truncate">{l.reason}</td>
                        <td className="py-2.5 px-3">
                          <StatusLabel label={l.status} />
                        </td>
                        {canApprove && (
                          <td className="py-2.5 pl-3 text-right">
                            {l.status === 'PENDING' ? (
                              <div className="inline-flex gap-1">
                                <button
                                  type="button"
                                  onClick={async () => {
                                    await dataService.reviewLeaveRequest(actor, l.id, 'APPROVED', 'Approved');
                                    onNotify('success', 'Leave Approved', 'Updated attendance/leave status.');
                                    onReload();
                                  }}
                                  className="p-1.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded hover:bg-emerald-100"
                                  title="Approve"
                                >
                                  <Check className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={async () => {
                                    await dataService.reviewLeaveRequest(actor, l.id, 'REJECTED', 'Rejected');
                                    onNotify('success', 'Leave Rejected', 'Request rejected.');
                                    onReload();
                                  }}
                                  className="p-1.5 bg-rose-50 text-rose-700 border border-rose-200 rounded hover:bg-rose-100"
                                  title="Reject"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ) : (
                              <span className="text-slate-400">{l.admin_remarks || '—'}</span>
                            )}
                          </td>
                        )}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export function AttendanceCorrectionsPage({
  actor,
  employees,
  schedules,
  holidays,
  attendance,
  corrections,
  onReload,
  onNotify,
}: {
  actor: UserProfile;
  employees: Employee[];
  schedules: Schedule[];
  holidays: Holiday[];
  attendance: AttendanceRecord[];
  corrections: AttendanceCorrection[];
  onReload: () => void;
  onNotify: (type: 'success' | 'error', title: string, desc?: string) => void;
}) {
  const [selectedAttId, setSelectedAttId] = useState(attendance[0]?.id ?? '');
  const selectedAtt = attendance.find((a) => a.id === selectedAttId) ?? attendance[0];
  const [timeIn, setTimeIn] = useState(() =>
    selectedAtt?.actual_time_in ? toManilaTime24(selectedAtt.actual_time_in).slice(0, 5) : '08:00'
  );
  const [timeOut, setTimeOut] = useState(() =>
    selectedAtt?.actual_time_out ? toManilaTime24(selectedAtt.actual_time_out).slice(0, 5) : '17:00'
  );
  const [reason, setReason] = useState('');
  const [saving, setSaving] = useState(false);

  function pickAttendance(id: string) {
    setSelectedAttId(id);
    const found = attendance.find((a) => a.id === id);
    if (found) {
      setTimeIn(found.actual_time_in ? toManilaTime24(found.actual_time_in).slice(0, 5) : '08:00');
      setTimeOut(found.actual_time_out ? toManilaTime24(found.actual_time_out).slice(0, 5) : '17:00');
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!selectedAtt || !reason.trim()) return;
    const emp = employees.find((x) => x.id === selectedAtt.employee_id);
    const sched = schedules.find((s) => s.id === (selectedAtt.schedule_id ?? emp?.schedule_id)) ?? schedules[0];
    const hol = holidays.find((h) => h.holiday_date === selectedAtt.work_date && h.is_verified) ?? null;
    if (!emp) return;

    setSaving(true);
    try {
      await dataService.correctAttendance(actor, selectedAtt, emp, sched, hol, {
        actual_time_in: timeIn ? buildManilaTimestamp(selectedAtt.work_date, timeIn) : null,
        actual_time_out: timeOut ? buildManilaTimestamp(selectedAtt.work_date, timeOut) : null,
        reason: reason.trim(),
      });
      setReason('');
      onNotify('success', 'Correction Recorded', `Traceable correction saved for ${emp.full_name}.`);
      onReload();
    } catch (err) {
      onNotify('error', 'Correction failed', (err as Error).message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-900">Attendance Corrections</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Original values are preserved in correction history; every adjustment requires a reason and audit log entry.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <form onSubmit={handleSubmit} className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-5 space-y-4 text-xs">
          <h2 className="text-sm font-semibold text-slate-900">Apply Traceable Correction</h2>
          <div>
            <label className="block font-medium text-slate-700 mb-1">Attendance Record</label>
            <select
              value={selectedAtt?.id ?? ''}
              onChange={(e) => pickAttendance(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-white"
            >
              {attendance.map((a) => {
                const emp = employees.find((e) => e.id === a.employee_id);
                return (
                  <option key={a.id} value={a.id}>
                    {a.work_date} · {emp?.employee_number} — {emp?.full_name} ({a.status})
                  </option>
                );
              })}
            </select>
          </div>

          {selectedAtt && (
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
              <p className="font-medium text-slate-700">Current Recorded Values</p>
              <p className="font-mono text-slate-600">
                In: {formatManilaTime(selectedAtt.actual_time_in)} · Out: {formatManilaTime(selectedAtt.actual_time_out)}
              </p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Corrected Time In</label>
              <input
                type="time"
                value={timeIn}
                onChange={(e) => setTimeIn(e.target.value)}
                className="w-full px-3 py-2 font-mono border border-slate-200 rounded-lg"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Corrected Time Out</label>
              <input
                type="time"
                value={timeOut}
                onChange={(e) => setTimeOut(e.target.value)}
                className="w-full px-3 py-2 font-mono border border-slate-200 rounded-lg"
              />
            </div>
          </div>

          <div>
            <label className="block font-medium text-slate-700 mb-1">Mandatory Correction Reason *</label>
            <input
              type="text"
              required
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Missed evening clock-out verified by supervisor"
              className="w-full px-3 py-2 border border-slate-200 rounded-lg"
            />
          </div>

          <button
            type="submit"
            disabled={saving || !selectedAtt}
            className="w-full py-2.5 px-4 font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg inline-flex items-center justify-center gap-1.5"
          >
            <Wrench className="w-3.5 h-3.5" />
            {saving ? 'Applying...' : 'Save Traceable Correction'}
          </button>
        </form>

        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-5">
          <h2 className="text-sm font-semibold text-slate-900 mb-3">Correction Trail</h2>
          {corrections.length === 0 ? (
            <EmptyState
              title="No corrections recorded"
              description="All attendance corrections preserve original timestamps here."
            />
          ) : (
            <div className="divide-y divide-slate-100 text-xs">
              {corrections.map((c) => {
                const emp = employees.find((e) => e.id === c.employee_id);
                return (
                  <div key={c.id} className="py-3 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-slate-900">
                        {emp?.full_name} ({emp?.employee_number})
                      </span>
                      <span className="font-mono text-slate-500">{formatManilaDate(c.work_date)}</span>
                    </div>
                    <p className="text-slate-600">Reason: {c.reason}</p>
                    <p className="font-mono text-[11px] text-slate-500">
                      Original In/Out: {formatManilaTime(String(c.original_values.actual_time_in ?? ''))} –{' '}
                      {formatManilaTime(String(c.original_values.actual_time_out ?? ''))} → Corrected:{' '}
                      {formatManilaTime(String(c.corrected_values.actual_time_in ?? ''))} –{' '}
                      {formatManilaTime(String(c.corrected_values.actual_time_out ?? ''))}
                    </p>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
