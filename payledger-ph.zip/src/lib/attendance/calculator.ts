import type { AttendanceStatus, DayClassification, Holiday, Schedule } from '../../types/database';
import { addDaysToDateString, buildManilaTimestamp, getManilaDayOfWeek } from '../date/manila';

export interface AttendanceCalculationInput {
  workDate: string;
  schedule: Pick<
    Schedule,
    'time_in' | 'time_out' | 'lunch_break_minutes' | 'grace_period_minutes' | 'regular_hours' | 'is_overnight' | 'is_flexible'
  >;
  actualTimeIn: string | null;
  actualTimeOut: string | null;
  restDays: number[];
  holiday?: Holiday | null;
  approvedOvertimeHours?: number;
  hasApprovedLeave?: boolean;
}

export interface AttendanceCalculationResult {
  scheduledTimeIn: string;
  scheduledTimeOut: string;
  earlyArrivalMinutes: number;
  lateMinutes: number;
  undertimeMinutes: number;
  actualHours: number;
  regularHours: number;
  paidHours: number;
  potentialOvertimeHours: number;
  approvedOvertimeHours: number;
  status: AttendanceStatus;
  dayClassification: DayClassification;
  isRestDay: boolean;
}

export function classifyDay(
  workDate: string,
  restDays: number[],
  holiday?: Holiday | null
): { dayClassification: DayClassification; isRestDay: boolean } {
  const dow = getManilaDayOfWeek(workDate);
  const isRestDay = restDays.includes(dow);

  if (holiday && holiday.is_verified) {
    if (holiday.holiday_type === 'REGULAR') {
      return {
        dayClassification: isRestDay ? 'REGULAR_HOLIDAY_REST_DAY' : 'REGULAR_HOLIDAY',
        isRestDay,
      };
    }
    if (holiday.holiday_type === 'SPECIAL_NON_WORKING') {
      return {
        dayClassification: isRestDay ? 'SPECIAL_HOLIDAY_REST_DAY' : 'SPECIAL_HOLIDAY',
        isRestDay,
      };
    }
  }

  if (isRestDay) {
    return { dayClassification: 'REST_DAY', isRestDay: true };
  }
  return { dayClassification: 'ORDINARY', isRestDay: false };
}

export function calculateAttendanceMetrics(input: AttendanceCalculationInput): AttendanceCalculationResult {
  const {
    workDate,
    schedule,
    actualTimeIn,
    actualTimeOut,
    restDays,
    holiday,
    approvedOvertimeHours = 0,
    hasApprovedLeave = false,
  } = input;

  const outDate = schedule.is_overnight ? addDaysToDateString(workDate, 1) : workDate;
  const scheduledTimeIn = buildManilaTimestamp(workDate, schedule.time_in);
  const scheduledTimeOut = buildManilaTimestamp(outDate, schedule.time_out);

  const { dayClassification, isRestDay } = classifyDay(workDate, restDays, holiday);

  if (!actualTimeIn) {
    let status: AttendanceStatus = 'ABSENT';
    if (hasApprovedLeave) status = 'LEAVE';
    else if (holiday && holiday.is_verified && holiday.holiday_type !== 'SPECIAL_WORKING') status = 'HOLIDAY';
    else if (isRestDay) status = 'REST_DAY';

    return {
      scheduledTimeIn,
      scheduledTimeOut,
      earlyArrivalMinutes: 0,
      lateMinutes: 0,
      undertimeMinutes: 0,
      actualHours: 0,
      regularHours: 0,
      paidHours: 0,
      potentialOvertimeHours: 0,
      approvedOvertimeHours: 0,
      status,
      dayClassification,
      isRestDay,
    };
  }

  const schedInMs = new Date(scheduledTimeIn).getTime();
  const schedOutMs = new Date(scheduledTimeOut).getTime();
  const actInMs = new Date(actualTimeIn).getTime();
  const graceMs = Math.max(0, schedule.grace_period_minutes) * 60_000;

  let earlyArrivalMinutes = 0;
  let lateMinutes = 0;

  if (!schedule.is_flexible) {
    if (actInMs < schedInMs) {
      earlyArrivalMinutes = Math.floor((schedInMs - actInMs) / 60_000);
    } else if (actInMs > schedInMs + graceMs) {
      lateMinutes = Math.floor((actInMs - (schedInMs + graceMs)) / 60_000);
    }
  }

  let status: AttendanceStatus = lateMinutes > 0 ? 'LATE' : 'ON_TIME';

  if (!actualTimeOut) {
    return {
      scheduledTimeIn,
      scheduledTimeOut,
      earlyArrivalMinutes,
      lateMinutes,
      undertimeMinutes: 0,
      actualHours: 0,
      regularHours: 0,
      paidHours: 0,
      potentialOvertimeHours: 0,
      approvedOvertimeHours: 0,
      status,
      dayClassification,
      isRestDay,
    };
  }

  const actOutMs = new Date(actualTimeOut).getTime();
  let undertimeMinutes = 0;
  if (!schedule.is_flexible && actOutMs < schedOutMs) {
    undertimeMinutes = Math.floor((schedOutMs - actOutMs) / 60_000);
  }

  // Early arrival is NOT automatically payable overtime; effective work start is max(actualIn, schedIn) for standard shifts
  const effectiveStartMs = schedule.is_flexible ? actInMs : Math.max(actInMs, schedInMs);
  const rawWorkedHours = Math.max(0, (actOutMs - effectiveStartMs) / 3_600_000);
  const lunchDeductionHours = rawWorkedHours > 4 ? schedule.lunch_break_minutes / 60 : 0;
  const netActualHours = Math.max(0, Number((rawWorkedHours - lunchDeductionHours).toFixed(2)));

  const regularHours = Number(Math.min(schedule.regular_hours, netActualHours).toFixed(2));
  const potentialOvertimeHours = !schedule.is_flexible && actOutMs > schedOutMs
    ? Number(((actOutMs - schedOutMs) / 3_600_000).toFixed(2))
    : Number(Math.max(0, netActualHours - schedule.regular_hours).toFixed(2));

  const verifiedApprovedOt = Number(Math.min(approvedOvertimeHours, potentialOvertimeHours).toFixed(2));
  if (verifiedApprovedOt > 0 && lateMinutes === 0) {
    status = 'OVERTIME';
  }

  const paidHours = Number((regularHours + verifiedApprovedOt).toFixed(2));

  return {
    scheduledTimeIn,
    scheduledTimeOut,
    earlyArrivalMinutes,
    lateMinutes,
    undertimeMinutes,
    actualHours: netActualHours,
    regularHours,
    paidHours,
    potentialOvertimeHours,
    approvedOvertimeHours: verifiedApprovedOt,
    status,
    dayClassification,
    isRestDay,
  };
}
