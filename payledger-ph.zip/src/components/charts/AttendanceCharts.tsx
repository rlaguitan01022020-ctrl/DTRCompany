import React from 'react';
import type { AttendanceRecord, Employee } from '../../types/database';

export function DailyStatusBreakdownBar({
  counts,
}: {
  counts: { onTime: number; late: number; overtime: number; leave: number; absent: number };
}) {
  const total = Math.max(1, counts.onTime + counts.late + counts.overtime + counts.leave + counts.absent);
  const items = [
    { label: 'On Time', value: counts.onTime, color: 'bg-emerald-600' },
    { label: 'Late', value: counts.late, color: 'bg-rose-600' },
    { label: 'Overtime', value: counts.overtime, color: 'bg-amber-500' },
    { label: 'On Leave', value: counts.leave, color: 'bg-blue-600' },
    { label: 'Absent', value: counts.absent, color: 'bg-slate-400' },
  ];

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shadow-sm dark:shadow-lg dark:shadow-black/30 rounded-lg p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">Daily Attendance Distribution</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Headcount breakdown for selected date</p>
        </div>
        <span className="text-xs font-mono tabular-nums text-slate-600 dark:text-slate-300">
          {counts.onTime + counts.late + counts.overtime + counts.leave + counts.absent} Total
        </span>
      </div>

      <div className="h-3 w-full rounded bg-slate-100 dark:bg-slate-800 overflow-hidden flex border border-slate-200 dark:border-slate-700">
        {items.map((item) => {
          const pct = (item.value / total) * 100;
          if (pct <= 0) return null;
          return (
            <div
              key={item.label}
              style={{ width: `${pct}%` }}
              className={`${item.color} h-full transition-all`}
              title={`${item.label}: ${item.value}`}
            />
          );
        })}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mt-4">
        {items.map((item) => (
          <div key={item.label} className="flex items-center justify-between border border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-800/60 shadow-2xs rounded px-2.5 py-2">
            <div className="flex items-center gap-2 min-w-0">
              <span className={`w-2.5 h-2.5 rounded-sm shrink-0 ${item.color}`} />
              <span className="text-xs text-slate-600 dark:text-slate-300 truncate">{item.label}</span>
            </div>
            <span className="text-xs font-mono font-semibold tabular-nums text-slate-900 dark:text-slate-100">{item.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function DepartmentAttendanceChart({
  employees,
  todayRecords,
}: {
  employees: Employee[];
  todayRecords: AttendanceRecord[];
}) {
  const deptMap = new Map<string, { total: number; present: number; late: number }>();
  const presentSet = new Map(todayRecords.map((r) => [r.employee_id, r]));

  for (const emp of employees.filter((e) => e.is_active)) {
    const entry = deptMap.get(emp.department) ?? { total: 0, present: 0, late: 0 };
    entry.total += 1;
    const rec = presentSet.get(emp.id);
    if (rec?.actual_time_in) {
      entry.present += 1;
      if (rec.late_minutes > 0) entry.late += 1;
    }
    deptMap.set(emp.department, entry);
  }

  const rows = Array.from(deptMap.entries()).sort((a, b) => b[1].total - a[1].total);

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shadow-sm dark:shadow-lg dark:shadow-black/30 rounded-lg p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">Department Attendance</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Active headcount vs present today</p>
        </div>
      </div>
      {rows.length === 0 ? (
        <p className="text-xs text-slate-500 dark:text-slate-400 py-6 text-center">No active departments found.</p>
      ) : (
        <div className="space-y-3">
          {rows.map(([dept, stats]) => {
            const pct = stats.total > 0 ? Math.round((stats.present / stats.total) * 100) : 0;
            return (
              <div key={dept} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium text-slate-700 dark:text-slate-200">{dept}</span>
                  <span className="font-mono tabular-nums text-slate-600 dark:text-slate-400">
                    {stats.present}/{stats.total} ({pct}%)
                    {stats.late > 0 ? ` · ${stats.late} late` : ''}
                  </span>
                </div>
                <div className="h-2 bg-slate-100 dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700 rounded overflow-hidden">
                  <div className="h-full bg-blue-600 dark:bg-blue-500 rounded" style={{ width: `${pct}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
