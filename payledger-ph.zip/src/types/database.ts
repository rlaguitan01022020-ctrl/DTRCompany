export type UserRole = 'SUPER_ADMIN' | 'ADMIN' | 'HR' | 'EMPLOYEE';
export type EmploymentType = 'REGULAR' | 'PROBATIONARY' | 'CONTRACTUAL' | 'PART_TIME';
export type EmploymentStatus = 'ACTIVE' | 'INACTIVE' | 'RESIGNED' | 'TERMINATED';
export type SalaryType = 'DAILY' | 'HOURLY' | 'MONTHLY';
export type AttendanceStatus =
  | 'PRESENT'
  | 'ON_TIME'
  | 'LATE'
  | 'OVERTIME'
  | 'ABSENT'
  | 'LEAVE'
  | 'REST_DAY'
  | 'HOLIDAY'
  | 'INCOMPLETE';
export type OvertimeStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'DECLINED_BY_EMPLOYEE';
export type LeaveStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'CANCELLED';
export type HolidayType = 'REGULAR' | 'SPECIAL_NON_WORKING' | 'SPECIAL_WORKING';
export type PayrollStatus = 'DRAFT' | 'FOR_REVIEW' | 'APPROVED' | 'FINALIZED' | 'PAID';
export type CredentialStatus = 'ACTIVE' | 'SUSPENDED' | 'REVOKED';
export type DayClassification =
  | 'ORDINARY'
  | 'REST_DAY'
  | 'SPECIAL_HOLIDAY'
  | 'SPECIAL_HOLIDAY_REST_DAY'
  | 'REGULAR_HOLIDAY'
  | 'REGULAR_HOLIDAY_REST_DAY';

export interface UserPermissions {
  can_edit_salary: boolean;
  can_manage_payroll: boolean;
  can_manage_holidays: boolean;
  can_view_reports: boolean;
}

export interface MultiplierPair {
  first8: number;
  overtime: number;
}

export interface HolidayMultipliers {
  ordinary: MultiplierPair;
  rest_day: MultiplierPair;
  special_holiday: MultiplierPair;
  special_holiday_rest_day: MultiplierPair;
  regular_holiday: MultiplierPair;
  regular_holiday_rest_day: MultiplierPair;
}

export interface CompanySettings {
  id: string;
  company_name: string;
  company_logo_url: string | null;
  company_address: string;
  contact_number: string;
  company_email: string;
  timezone: string;
  working_days: number[];
  default_schedule_id: string | null;
  default_time_in: string; // HH:mm:ss
  default_time_out: string; // HH:mm:ss
  lunch_break_minutes: number;
  grace_period_minutes: number;
  regular_working_hours: number;
  default_rest_days: number[];
  payroll_schedule: 'WEEKLY' | 'SEMI_MONTHLY' | 'MONTHLY';
  employee_number_prefix: string;
  require_kiosk_pin: boolean;
  theme?: 'light' | 'dark';
  payslip_note?: string;
  multipliers: HolidayMultipliers;
}

export interface Schedule {
  id: string;
  name: string;
  time_in: string;
  time_out: string;
  lunch_break_minutes: number;
  grace_period_minutes: number;
  regular_hours: number;
  is_flexible: boolean;
  is_overnight: boolean;
  is_default: boolean;
}

export interface EmployeeDeductionsBreakdown {
  sss_share?: number;
  sss_share_remarks?: string;
  phic_share?: number;
  phic_share_remarks?: string;
  pagibig_share?: number;
  sss_loan?: number;
  pagibig_loan?: number;
  coop_share?: number;
  coop_loan?: number;
  donation?: number;
  cash_advance?: number;
}

export interface Employee {
  id: string;
  employee_number: string;
  full_name: string;
  photo_url: string | null;
  position: string;
  department: string;
  contact_number: string;
  address: string;
  email: string;
  date_hired: string;
  employment_type: EmploymentType;
  employment_status: EmploymentStatus;
  schedule_id: string | null;
  rest_days: number[];
  salary_type: SalaryType;
  daily_rate: number;
  hourly_rate: number;
  monthly_rate: number;
  overtime_rate: number;
  meal_allowance: number;
  transport_allowance: number;
  other_allowances: number;
  default_deductions: number;
  sss_share?: number;
  sss_share_remarks?: string;
  phic_share?: number;
  phic_share_remarks?: string;
  pagibig_share?: number;
  sss_loan?: number;
  pagibig_loan?: number;
  coop_share?: number;
  coop_loan?: number;
  donation?: number;
  cash_advance?: number;
  is_active: boolean;
  deactivated_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface EmployeeNumberCredential {
  id: string;
  employee_id: string;
  employee_number: string;
  credential_status: CredentialStatus;
  pin_required: boolean;
  pin_plain_preview?: string; // only used in local preview mode
  issued_at: string;
  revoked_at: string | null;
  revoked_reason: string | null;
}

export interface UserProfile {
  id: string;
  email: string;
  full_name: string;
  avatar_url: string | null;
  phone: string | null;
  address: string | null;
  department: string | null;
  position: string | null;
  role: UserRole;
  employee_id: string | null;
  employee_number: string | null;
  permissions: UserPermissions;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface SalaryHistoryRecord {
  id: string;
  employee_id: string;
  salary_type: SalaryType;
  previous_daily_rate: number;
  new_daily_rate: number;
  previous_hourly_rate: number;
  new_hourly_rate: number;
  previous_monthly_rate: number;
  new_monthly_rate: number;
  previous_overtime_rate: number;
  new_overtime_rate: number;
  previous_allowances: number;
  new_allowances: number;
  previous_deductions: number;
  new_deductions: number;
  deductions_snapshot?: EmployeeDeductionsBreakdown | null;
  effective_date: string;
  reason: string;
  changed_by: string | null;
  changed_by_name?: string;
  created_at: string;
}

export interface Holiday {
  id: string;
  holiday_date: string;
  name: string;
  holiday_type: HolidayType;
  description: string | null;
  is_verified: boolean;
  source: string;
  created_at: string;
}

export interface AttendanceRecord {
  id: string;
  employee_id: string;
  work_date: string;
  schedule_id: string | null;
  scheduled_time_in: string | null;
  scheduled_time_out: string | null;
  actual_time_in: string | null;
  actual_time_out: string | null;
  early_arrival_minutes: number;
  late_minutes: number;
  undertime_minutes: number;
  regular_hours: number;
  actual_hours: number;
  paid_hours: number;
  approved_overtime_hours: number;
  status: AttendanceStatus;
  day_classification: DayClassification;
  is_rest_day: boolean;
  holiday_id: string | null;
  is_corrected: boolean;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface AttendanceEvent {
  id: string;
  attendance_id: string;
  employee_id: string;
  employee_number: string;
  event_type: 'TIME_IN' | 'TIME_OUT';
  recorded_at: string;
  work_date: string;
  source: 'TERMINAL' | 'KIOSK' | 'ADMIN_CORRECTION';
  device_info: string | null;
}

export interface AttendanceCorrection {
  id: string;
  attendance_id: string;
  employee_id: string;
  work_date: string;
  original_values: Record<string, unknown>;
  corrected_values: Record<string, unknown>;
  reason: string;
  corrected_by: string | null;
  corrected_by_name?: string;
  created_at: string;
}

export interface OvertimeRequest {
  id: string;
  attendance_id: string | null;
  employee_id: string;
  work_date: string;
  scheduled_time_in: string | null;
  actual_time_in: string | null;
  scheduled_time_out: string | null;
  actual_time_out: string | null;
  decision: 'YES' | 'NO';
  requested_hours: number;
  verified_hours: number;
  approved_hours: number;
  overtime_rate_applied: number;
  approved_amount: number;
  reason: string;
  status: OvertimeStatus;
  admin_remarks: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  created_at: string;
}

export interface LeaveRequest {
  id: string;
  employee_id: string;
  leave_type: string;
  start_date: string;
  end_date: string;
  total_days: number;
  is_paid: boolean;
  reason: string;
  attachment_path: string | null;
  status: LeaveStatus;
  admin_remarks: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  created_at: string;
}

export interface PayrollPeriod {
  id: string;
  period_name: string;
  start_date: string;
  end_date: string;
  pay_date: string;
  payroll_schedule: string;
  status: PayrollStatus;
  generated_by: string | null;
  approved_by: string | null;
  finalized_by: string | null;
  finalized_at: string | null;
  paid_at: string | null;
  created_at: string;
}

export interface PayrollRecord {
  id: string;
  payroll_period_id: string;
  employee_id: string;
  employee_number: string;
  employee_name: string;
  department: string;
  position: string;
  salary_type: SalaryType;
  rate_snapshot: {
    daily_rate: number;
    hourly_rate: number;
    monthly_rate: number;
    overtime_rate: number;
    meal_allowance: number;
    transport_allowance: number;
    other_allowances: number;
    default_deductions: number;
    sss_share?: number;
    sss_share_remarks?: string;
    phic_share?: number;
    phic_share_remarks?: string;
    pagibig_share?: number;
    sss_loan?: number;
    pagibig_loan?: number;
    coop_share?: number;
    coop_loan?: number;
    donation?: number;
    cash_advance?: number;
    regular_ot_hours?: number;
    premium_ot_hours?: number;
  };
  multipliers_snapshot: HolidayMultipliers;
  days_worked: number;
  regular_hours: number;
  approved_overtime_hours: number;
  basic_pay: number;
  regular_workday_pay: number;
  rest_day_pay: number;
  special_holiday_pay: number;
  regular_holiday_pay: number;
  holiday_rest_day_pay: number;
  regular_overtime_pay: number;
  rest_day_overtime_pay: number;
  holiday_overtime_pay: number;
  allowances_total: number;
  absence_deductions: number;
  undertime_deductions: number;
  other_deductions: number;
  adjustments_total: number;
  gross_pay: number;
  net_pay: number;
  attendance_refs: string[];
  overtime_refs: string[];
  is_locked: boolean;
  created_at: string;
  updated_at: string;
}

export interface PayrollAdjustment {
  id: string;
  payroll_record_id: string;
  payroll_period_id: string;
  employee_id: string;
  adjustment_type: 'ADDITION' | 'DEDUCTION';
  category: string;
  amount: number;
  reason: string;
  created_by: string | null;
  created_at: string;
}

export interface AuditLog {
  id: string;
  actor_user_id: string | null;
  actor_role: string | null;
  actor_name?: string;
  action: string;
  table_name: string;
  record_id: string | null;
  previous_value: Record<string, unknown> | null;
  new_value: Record<string, unknown> | null;
  reason: string | null;
  created_at: string;
}

export interface IntegrationSyncItem {
  id: string;
  provider: string;
  sheet_tab: string;
  record_type: string;
  record_id: string;
  idempotency_key: string;
  payload: Record<string, unknown>;
  status: 'PENDING' | 'SYNCED' | 'FAILED';
  retry_count: number;
  last_error: string | null;
  synced_at: string | null;
  created_at: string;
}

export interface AttendancePunchResult {
  success: boolean;
  event_type?: 'TIME_IN' | 'TIME_OUT';
  error_code?: string;
  message?: string;
  employee_id?: string;
  employee_number?: string;
  full_name?: string;
  position?: string;
  department?: string;
  photo_url?: string | null;
  work_date?: string;
  recorded_at?: string;
  status?: AttendanceStatus;
  late_minutes?: number;
  undertime_minutes?: number;
}
